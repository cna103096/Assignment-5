﻿/* Z1829678 - Christopher Adams
 * Z1805732 - Kevin Lewis 
 *                                      
 * 
 * CSCI 473 - Assignment 5: Sudoku
 * Creates a soduku like puzzle with addition in each row, column, and diagonal
 * */

using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;
using System.Timers;

namespace Assignment_5
{
    public partial class Form1 : Form
    {
        //initial puzzles
        public static int[,] easyPuzzlesInitial = new int[3, 9];
        public static int[,] mediumPuzzlesInitial = new int[3, 25];
        public static int[,] hardPuzzlesInitial = new int[3, 49];

        //puzzle solutions
        public static int[,] easyPuzzlesSolution = new int[3, 9];
        public static int[,] mediumPuzzlesSolution = new int[3, 25];
        public static int[,] hardPuzzlesSolution = new int[3, 49];

        //puzzles progress 
        public static int[,] easyPuzzlesProgress = new int[3, 9];
        public static int[,] mediumPuzzlesProgress = new int[3, 25];
        public static int[,] hardPuzzlesProgress = new int[3, 49];

        //completion times
        public static float[] easyTimeArray = { 0, 0, 0 };
        public static float[] mediumTimeArray = { 0, 0, 0 };
        public static float[] hardTimeArray = { 0, 0, 0 };

        public static List<float> easyTime = new List<float>();
        public static List<float> mediumTime = new List<float>();
        public static List<float> hardTime = new List<float>();

        //rng
        Random rand = new Random();

        public static int[] activePuzzle;
        public static uint activePuzzleNum = 100;

        //Global variables and objects
        private bool cheatFlag = false;
        //private System.Timers.Timer masterTimer = new System.Timers.Timer(1000);
        private static Stopwatch time = new Stopwatch();

        //Completed puzzles


        public static Color correctColor = Color.Green;
        public static Color neutralColor = Color.Gray;
        public static Color wrongColor = Color.Red;
        public Form1()
        {
            InitializeComponent();
            ComboBox_Difficulty.SelectedIndex = 0;
            Read_Files();

        }

        /*Read data
         * reads in the puzzles
         * filename is location of file, num is the puzzle number
         * */
        public void Read_Data(string fileName, uint num)
        {
            string read = "";
            using (StreamReader inFile = new StreamReader(fileName))
            {
                read = inFile.ReadLine();

                switch (read.Length)
                {
                    //easy
                    case 3:

                        int p = 0;
                        //iterate through puzzle
                        for (int j = 0; j < easyPuzzlesInitial.GetLength(1); j++)
                        {
                            //put number into array
                            easyPuzzlesInitial[num, j] = (int)Char.GetNumericValue(read[p]);
                            //iterate position of character in readline
                            p++;
                            //if p is done, get next line and reset p
                            if (p == read.Length)
                            {
                                p = 0;
                                read = inFile.ReadLine();
                            }

                        }
                        read = inFile.ReadLine();
                        p = 0;
                        for (int j = 0; j < easyPuzzlesSolution.GetLength(1); j++)
                        {
                            easyPuzzlesSolution[num, j] = (int)Char.GetNumericValue(read[p]);

                            p++;
                            if (p == read.Length)
                            {
                                p = 0;
                                read = inFile.ReadLine();
                            }
                        }
                        //progress will always start at initial values
                        easyPuzzlesProgress = easyPuzzlesInitial;

                        break;
                    //medium
                    case 5:
                        p = 0;
                        //iterate through puzzle
                        for (int j = 0; j < mediumPuzzlesInitial.GetLength(1); j++)
                        {
                            //put number into array
                            mediumPuzzlesInitial[num, j] = (int)Char.GetNumericValue(read[p]);
                            //iterate position of character in readline
                            p++;
                            //if p is done, get next line and reset p
                            if (p == read.Length)
                            {
                                p = 0;
                                read = inFile.ReadLine();
                            }

                        }
                        read = inFile.ReadLine();
                        p = 0;
                        for (int j = 0; j < mediumPuzzlesSolution.GetLength(1); j++)
                        {
                            mediumPuzzlesSolution[num, j] = (int)Char.GetNumericValue(read[p]);

                            p++;
                            if (p == read.Length)
                            {
                                p = 0;
                                read = inFile.ReadLine();
                            }
                        }
                        //progress will always start at initial values
                        mediumPuzzlesProgress = mediumPuzzlesInitial;

                        break;
                    //hard
                    case 7:
                        p = 0;
                        //iterate through puzzle
                        for (int j = 0; j < hardPuzzlesInitial.GetLength(1); j++)
                        {
                            //put number into array
                            hardPuzzlesInitial[num, j] = (int)Char.GetNumericValue(read[p]);
                            //iterate position of character in readline
                            p++;
                            //if p is done, get next line and reset p
                            if (p == read.Length)
                            {
                                p = 0;
                                read = inFile.ReadLine();
                            }

                        }
                        read = inFile.ReadLine();
                        p = 0;
                        for (int j = 0; j < hardPuzzlesSolution.GetLength(1); j++)
                        {
                            hardPuzzlesSolution[num, j] = (int)Char.GetNumericValue(read[p]);

                            p++;
                            if (p == read.Length)
                            {
                                p = 0;
                                read = inFile.ReadLine();
                            }
                        }
                        //progress will always start at initial values
                        hardPuzzlesProgress = hardPuzzlesInitial;

                        break;

                }
            }
        }

        /* Read Files
         * calls the read data method for each file
         * */
        private void Read_Files()
        {
            //easy files
            Read_Data("..\\..\\a5/easy/e1.txt", 0);
            Read_Data("..\\..\\a5/easy/e2.txt", 1);
            Read_Data("..\\..\\a5/easy/e3.txt", 2);
            //medium files
            Read_Data("..\\..\\a5/medium/m1.txt", 0);
            Read_Data("..\\..\\a5/medium/m2.txt", 1);
            Read_Data("..\\..\\a5/medium/m3.txt", 2);
            //hard files
            Read_Data("..\\..\\a5/hard/h1.txt", 0);
            Read_Data("..\\..\\a5/hard/h2.txt", 1);
            Read_Data("..\\..\\a5/hard/h3.txt", 2);
        }


        /* Button Create Puzzle Click
         * Generates a new puzzle based on selected difficulty
         * */
        private void Button_Create_Puzzle_Click(object sender, EventArgs e)
        {
            Button_Pause.Enabled = true;
            Button_Cheat.Enabled = true;
            //save current progress if puzzle in progress
            if (activePuzzleNum != 100)
            {
                switch (activePuzzle.Length)
                {
                    case 9:
                        //save progress
                        oneToTwoArray(easyPuzzlesProgress, activePuzzleNum);
                        easyTimeArray[activePuzzleNum] = (float)time.ElapsedMilliseconds;
                        break;
                    case 25:
                        //save progress
                        oneToTwoArray(mediumPuzzlesProgress, activePuzzleNum);
                        mediumTimeArray[activePuzzleNum] = (float)time.ElapsedMilliseconds;
                        break;
                    case 49:
                        //save progress
                        oneToTwoArray(hardPuzzlesProgress, activePuzzleNum);
                        mediumTimeArray[activePuzzleNum] = (float)time.ElapsedMilliseconds;
                        break;
                }
            }

            //default to easy
            uint diff = 0;

            Reset_Values();


            //easy
            if (ComboBox_Difficulty.SelectedIndex == 0)
            {
                diff = 0;
                Label_Difficulty.Text = "Easy Puzzle";
                //calls fill puzzle
                Choose_Easy();

            }
            //medium
            if (ComboBox_Difficulty.SelectedIndex == 1)
            {
                diff = 1;
                Label_Difficulty.Text = "Medium Puzzle";
                //calls fill puzzle
                Choose_Medium();
            }
            //hard
            if (ComboBox_Difficulty.SelectedIndex == 2)
            {
                diff = 2;
                Label_Difficulty.Text = "Hard Puzzle";
                //calls fill puzzle
                Choose_Hard();
            }

            Set_Difficulty(diff);
            Timer.Start();
            time.Restart();
        }


        /* Update Puzzle
         * updates current puzzle and check for sum
         * 
         * */
        public void Update_Puzzle()
        {
            /* 1  2  3  4  5  6  7      
            * 8  9  10 11 12 13 14      9  10 11 12 13
            * 15 16 17 18 19 20 21      16 17 18 19 20      17 18 19
            * 22 23 24 25 26 27 28      23 24 25 26 27      24 25 26
            * 29 30 31 32 33 34 35      30 31 32 33 34      31 32 33
            * 36 37 38 39 40 41 42      37 38 39 40 41
            * 43 44 45 46 47 48 49
            * */
            if (activePuzzleNum != 100)
            {
                switch (activePuzzle.Length)
                {
                    case 9:

                        if (Textbox_Puzzle_17.Text != "")
                            activePuzzle[0] = Convert.ToInt32(Textbox_Puzzle_17.Text);
                        if (Textbox_Puzzle_18.Text != "")
                            activePuzzle[1] = Convert.ToInt32(Textbox_Puzzle_18.Text);
                        if (Textbox_Puzzle_19.Text != "")
                            activePuzzle[2] = Convert.ToInt32(Textbox_Puzzle_19.Text);
                        if (Textbox_Puzzle_24.Text != "")
                            activePuzzle[3] = Convert.ToInt32(Textbox_Puzzle_24.Text);
                        if (Textbox_Puzzle_25.Text != "")
                            activePuzzle[4] = Convert.ToInt32(Textbox_Puzzle_25.Text);
                        if (Textbox_Puzzle_26.Text != "")
                            activePuzzle[5] = Convert.ToInt32(Textbox_Puzzle_26.Text);
                        if (Textbox_Puzzle_31.Text != "")
                            activePuzzle[6] = Convert.ToInt32(Textbox_Puzzle_31.Text);
                        if (Textbox_Puzzle_32.Text != "")
                            activePuzzle[7] = Convert.ToInt32(Textbox_Puzzle_32.Text);
                        if (Textbox_Puzzle_33.Text != "")
                            activePuzzle[8] = Convert.ToInt32(Textbox_Puzzle_33.Text);

                        //user sum labels
                        Label_Puzzle_R3.Text = Convert.ToString(activePuzzle[0] + activePuzzle[1] + activePuzzle[2]);
                        Label_Puzzle_R4.Text = Convert.ToString(activePuzzle[3] + activePuzzle[4] + activePuzzle[5]);
                        Label_Puzzle_R5.Text = "" + (activePuzzle[6] + activePuzzle[7] + activePuzzle[8]);

                        Label_Puzzle_C3.Text = Convert.ToString(activePuzzle[0] + activePuzzle[3] + activePuzzle[6]);
                        Label_Puzzle_C4.Text = Convert.ToString(activePuzzle[1] + activePuzzle[4] + activePuzzle[7]);
                        Label_Puzzle_C5.Text = Convert.ToString(activePuzzle[2] + activePuzzle[5] + activePuzzle[8]);

                        Label_Puzzle_D1.Text = Convert.ToString(activePuzzle[2] + activePuzzle[4] + activePuzzle[6]);
                        Label_Puzzle_D2.Text = Convert.ToString(activePuzzle[0] + activePuzzle[4] + activePuzzle[8]);

                        SumCheck();
                        break;

                    case 25:
                        if (Textbox_Puzzle_9.Text != "")
                            activePuzzle[0] = Convert.ToInt32(Textbox_Puzzle_9.Text);
                        if (Textbox_Puzzle_10.Text != "")
                            activePuzzle[1] = Convert.ToInt32(Textbox_Puzzle_10.Text);
                        if (Textbox_Puzzle_11.Text != "")
                            activePuzzle[2] = Convert.ToInt32(Textbox_Puzzle_11.Text);
                        if (Textbox_Puzzle_12.Text != "")
                            activePuzzle[3] = Convert.ToInt32(Textbox_Puzzle_12.Text);
                        if (Textbox_Puzzle_13.Text != "")
                            activePuzzle[4] = Convert.ToInt32(Textbox_Puzzle_13.Text);
                        if (Textbox_Puzzle_16.Text != "")
                            activePuzzle[5] = Convert.ToInt32(Textbox_Puzzle_16.Text);
                        if (Textbox_Puzzle_17.Text != "")
                            activePuzzle[6] = Convert.ToInt32(Textbox_Puzzle_17.Text);
                        if (Textbox_Puzzle_18.Text != "")
                            activePuzzle[7] = Convert.ToInt32(Textbox_Puzzle_18.Text);
                        if (Textbox_Puzzle_19.Text != "")
                            activePuzzle[8] = Convert.ToInt32(Textbox_Puzzle_19.Text);
                        if (Textbox_Puzzle_20.Text != "")
                            activePuzzle[9] = Convert.ToInt32(Textbox_Puzzle_20.Text);
                        if (Textbox_Puzzle_23.Text != "")
                            activePuzzle[10] = Convert.ToInt32(Textbox_Puzzle_23.Text);
                        if (Textbox_Puzzle_24.Text != "")
                            activePuzzle[11] = Convert.ToInt32(Textbox_Puzzle_24.Text);
                        if (Textbox_Puzzle_25.Text != "")
                            activePuzzle[12] = Convert.ToInt32(Textbox_Puzzle_25.Text);
                        if (Textbox_Puzzle_26.Text != "")
                            activePuzzle[13] = Convert.ToInt32(Textbox_Puzzle_26.Text);
                        if (Textbox_Puzzle_27.Text != "")
                            activePuzzle[14] = Convert.ToInt32(Textbox_Puzzle_27.Text);
                        if (Textbox_Puzzle_30.Text != "")
                            activePuzzle[15] = Convert.ToInt32(Textbox_Puzzle_30.Text);
                        if (Textbox_Puzzle_31.Text != "")
                            activePuzzle[16] = Convert.ToInt32(Textbox_Puzzle_31.Text);
                        if (Textbox_Puzzle_32.Text != "")
                            activePuzzle[17] = Convert.ToInt32(Textbox_Puzzle_32.Text);
                        if (Textbox_Puzzle_33.Text != "")
                            activePuzzle[18] = Convert.ToInt32(Textbox_Puzzle_33.Text);
                        if (Textbox_Puzzle_34.Text != "")
                            activePuzzle[19] = Convert.ToInt32(Textbox_Puzzle_34.Text);
                        if (Textbox_Puzzle_37.Text != "")
                            activePuzzle[20] = Convert.ToInt32(Textbox_Puzzle_37.Text);
                        if (Textbox_Puzzle_38.Text != "")
                            activePuzzle[21] = Convert.ToInt32(Textbox_Puzzle_38.Text);
                        if (Textbox_Puzzle_39.Text != "")
                            activePuzzle[22] = Convert.ToInt32(Textbox_Puzzle_39.Text);
                        if (Textbox_Puzzle_40.Text != "")
                            activePuzzle[23] = Convert.ToInt32(Textbox_Puzzle_40.Text);
                        if (Textbox_Puzzle_41.Text != "")
                            activePuzzle[24] = Convert.ToInt32(Textbox_Puzzle_41.Text);

                        //user sum labels
                        Label_Puzzle_R2.Text = Convert.ToString(activePuzzle[0] + activePuzzle[1] + activePuzzle[2] + activePuzzle[3] + activePuzzle[4]);
                        Label_Puzzle_R3.Text = Convert.ToString(activePuzzle[5] + activePuzzle[6] + activePuzzle[7] + activePuzzle[8] + activePuzzle[9]);
                        Label_Puzzle_R4.Text = Convert.ToString(activePuzzle[10] + activePuzzle[11] + activePuzzle[12] + activePuzzle[13] + activePuzzle[14]);
                        Label_Puzzle_R5.Text = Convert.ToString(activePuzzle[15] + activePuzzle[16] + activePuzzle[17] + activePuzzle[18] + activePuzzle[19]);
                        Label_Puzzle_R6.Text = Convert.ToString(activePuzzle[20] + activePuzzle[21] + activePuzzle[22] + activePuzzle[23] + activePuzzle[24]);

                        Label_Puzzle_C2.Text = Convert.ToString(activePuzzle[0] + activePuzzle[5] + activePuzzle[10] + activePuzzle[15] + activePuzzle[20]);
                        Label_Puzzle_C3.Text = Convert.ToString(activePuzzle[1] + activePuzzle[6] + activePuzzle[11] + activePuzzle[16] + activePuzzle[21]);
                        Label_Puzzle_C4.Text = Convert.ToString(activePuzzle[2] + activePuzzle[7] + activePuzzle[12] + activePuzzle[17] + activePuzzle[22]);
                        Label_Puzzle_C5.Text = Convert.ToString(activePuzzle[3] + activePuzzle[8] + activePuzzle[13] + activePuzzle[18] + activePuzzle[23]);
                        Label_Puzzle_C6.Text = Convert.ToString(activePuzzle[4] + activePuzzle[9] + activePuzzle[14] + activePuzzle[19] + activePuzzle[24]);

                        Label_Puzzle_D2.Text = Convert.ToString(activePuzzle[0] + activePuzzle[6] + activePuzzle[12] + activePuzzle[18] + activePuzzle[24]);
                        Label_Puzzle_D1.Text = Convert.ToString(activePuzzle[20] + activePuzzle[16] + activePuzzle[12] + activePuzzle[8] + activePuzzle[4]);

                        SumCheck();
                        break;
                    case 49:
                        if (Textbox_Puzzle_1.Text != "")
                            activePuzzle[0] = Convert.ToInt32(Textbox_Puzzle_1.Text);
                        if (Textbox_Puzzle_2.Text != "")
                            activePuzzle[1] = Convert.ToInt32(Textbox_Puzzle_2.Text);
                        if (Textbox_Puzzle_3.Text != "")
                            activePuzzle[2] = Convert.ToInt32(Textbox_Puzzle_3.Text);
                        if (Textbox_Puzzle_4.Text != "")
                            activePuzzle[3] = Convert.ToInt32(Textbox_Puzzle_4.Text);
                        if (Textbox_Puzzle_5.Text != "")
                            activePuzzle[4] = Convert.ToInt32(Textbox_Puzzle_5.Text);
                        if (Textbox_Puzzle_6.Text != "")
                            activePuzzle[5] = Convert.ToInt32(Textbox_Puzzle_6.Text);
                        if (Textbox_Puzzle_7.Text != "")
                            activePuzzle[6] = Convert.ToInt32(Textbox_Puzzle_7.Text);
                        if (Textbox_Puzzle_8.Text != "")
                            activePuzzle[7] = Convert.ToInt32(Textbox_Puzzle_8.Text);
                        if (Textbox_Puzzle_9.Text != "")
                            activePuzzle[8] = Convert.ToInt32(Textbox_Puzzle_9.Text);
                        if (Textbox_Puzzle_10.Text != "")
                            activePuzzle[9] = Convert.ToInt32(Textbox_Puzzle_10.Text);
                        if (Textbox_Puzzle_11.Text != "")
                            activePuzzle[10] = Convert.ToInt32(Textbox_Puzzle_11.Text);
                        if (Textbox_Puzzle_12.Text != "")
                            activePuzzle[11] = Convert.ToInt32(Textbox_Puzzle_12.Text);
                        if (Textbox_Puzzle_13.Text != "")
                            activePuzzle[12] = Convert.ToInt32(Textbox_Puzzle_13.Text);
                        if (Textbox_Puzzle_14.Text != "")
                            activePuzzle[13] = Convert.ToInt32(Textbox_Puzzle_14.Text);
                        if (Textbox_Puzzle_15.Text != "")
                            activePuzzle[14] = Convert.ToInt32(Textbox_Puzzle_15.Text);
                        if (Textbox_Puzzle_16.Text != "")
                            activePuzzle[15] = Convert.ToInt32(Textbox_Puzzle_16.Text);
                        if (Textbox_Puzzle_17.Text != "")
                            activePuzzle[16] = Convert.ToInt32(Textbox_Puzzle_17.Text);
                        if (Textbox_Puzzle_18.Text != "")
                            activePuzzle[17] = Convert.ToInt32(Textbox_Puzzle_18.Text);
                        if (Textbox_Puzzle_19.Text != "")
                            activePuzzle[18] = Convert.ToInt32(Textbox_Puzzle_19.Text);
                        if (Textbox_Puzzle_20.Text != "")
                            activePuzzle[19] = Convert.ToInt32(Textbox_Puzzle_20.Text);
                        if (Textbox_Puzzle_21.Text != "")
                            activePuzzle[20] = Convert.ToInt32(Textbox_Puzzle_21.Text);
                        if (Textbox_Puzzle_22.Text != "")
                            activePuzzle[21] = Convert.ToInt32(Textbox_Puzzle_22.Text);
                        if (Textbox_Puzzle_23.Text != "")
                            activePuzzle[22] = Convert.ToInt32(Textbox_Puzzle_23.Text);
                        if (Textbox_Puzzle_24.Text != "")
                            activePuzzle[23] = Convert.ToInt32(Textbox_Puzzle_24.Text);
                        if (Textbox_Puzzle_25.Text != "")
                            activePuzzle[24] = Convert.ToInt32(Textbox_Puzzle_25.Text);
                        if (Textbox_Puzzle_26.Text != "")
                            activePuzzle[25] = Convert.ToInt32(Textbox_Puzzle_26.Text);
                        if (Textbox_Puzzle_27.Text != "")
                            activePuzzle[26] = Convert.ToInt32(Textbox_Puzzle_27.Text);
                        if (Textbox_Puzzle_28.Text != "")
                            activePuzzle[27] = Convert.ToInt32(Textbox_Puzzle_28.Text);
                        if (Textbox_Puzzle_29.Text != "")
                            activePuzzle[28] = Convert.ToInt32(Textbox_Puzzle_29.Text);
                        if (Textbox_Puzzle_30.Text != "")
                            activePuzzle[29] = Convert.ToInt32(Textbox_Puzzle_30.Text);
                        if (Textbox_Puzzle_31.Text != "")
                            activePuzzle[30] = Convert.ToInt32(Textbox_Puzzle_31.Text);
                        if (Textbox_Puzzle_32.Text != "")
                            activePuzzle[31] = Convert.ToInt32(Textbox_Puzzle_32.Text);
                        if (Textbox_Puzzle_33.Text != "")
                            activePuzzle[32] = Convert.ToInt32(Textbox_Puzzle_33.Text);
                        if (Textbox_Puzzle_34.Text != "")
                            activePuzzle[33] = Convert.ToInt32(Textbox_Puzzle_34.Text);
                        if (Textbox_Puzzle_35.Text != "")
                            activePuzzle[34] = Convert.ToInt32(Textbox_Puzzle_35.Text);
                        if (Textbox_Puzzle_36.Text != "")
                            activePuzzle[35] = Convert.ToInt32(Textbox_Puzzle_36.Text);
                        if (Textbox_Puzzle_37.Text != "")
                            activePuzzle[36] = Convert.ToInt32(Textbox_Puzzle_37.Text);
                        if (Textbox_Puzzle_38.Text != "")
                            activePuzzle[37] = Convert.ToInt32(Textbox_Puzzle_38.Text);
                        if (Textbox_Puzzle_39.Text != "")
                            activePuzzle[38] = Convert.ToInt32(Textbox_Puzzle_39.Text);
                        if (Textbox_Puzzle_40.Text != "")
                            activePuzzle[39] = Convert.ToInt32(Textbox_Puzzle_40.Text);
                        if (Textbox_Puzzle_41.Text != "")
                            activePuzzle[40] = Convert.ToInt32(Textbox_Puzzle_41.Text);
                        if (Textbox_Puzzle_42.Text != "")
                            activePuzzle[41] = Convert.ToInt32(Textbox_Puzzle_42.Text);
                        if (Textbox_Puzzle_43.Text != "")
                            activePuzzle[42] = Convert.ToInt32(Textbox_Puzzle_43.Text);
                        if (Textbox_Puzzle_44.Text != "")
                            activePuzzle[43] = Convert.ToInt32(Textbox_Puzzle_44.Text);
                        if (Textbox_Puzzle_45.Text != "")
                            activePuzzle[44] = Convert.ToInt32(Textbox_Puzzle_45.Text);
                        if (Textbox_Puzzle_46.Text != "")
                            activePuzzle[45] = Convert.ToInt32(Textbox_Puzzle_46.Text);
                        if (Textbox_Puzzle_47.Text != "")
                            activePuzzle[46] = Convert.ToInt32(Textbox_Puzzle_47.Text);
                        if (Textbox_Puzzle_48.Text != "")
                            activePuzzle[47] = Convert.ToInt32(Textbox_Puzzle_48.Text);
                        if (Textbox_Puzzle_49.Text != "")
                            activePuzzle[48] = Convert.ToInt32(Textbox_Puzzle_49.Text);

                        //user sum labels
                        Label_Puzzle_R1.Text = Convert.ToString(activePuzzle[0] + activePuzzle[1] + activePuzzle[2] + activePuzzle[3] + activePuzzle[4] + activePuzzle[5] + activePuzzle[6]);
                        Label_Puzzle_R2.Text = Convert.ToString(activePuzzle[7] + activePuzzle[8] + activePuzzle[9] + activePuzzle[10] + activePuzzle[11] + activePuzzle[12] + activePuzzle[13]);
                        Label_Puzzle_R3.Text = Convert.ToString(activePuzzle[14] + activePuzzle[15] + activePuzzle[16] + activePuzzle[17] + activePuzzle[18] + activePuzzle[19] + activePuzzle[20]);
                        Label_Puzzle_R4.Text = Convert.ToString(activePuzzle[21] + activePuzzle[22] + activePuzzle[23] + activePuzzle[24] + activePuzzle[25] + activePuzzle[26] + activePuzzle[27]);
                        Label_Puzzle_R5.Text = Convert.ToString(activePuzzle[28] + activePuzzle[29] + activePuzzle[30] + activePuzzle[31] + activePuzzle[32] + activePuzzle[33] + activePuzzle[34]);
                        Label_Puzzle_R6.Text = Convert.ToString(activePuzzle[35] + activePuzzle[36] + activePuzzle[37] + activePuzzle[38] + activePuzzle[39] + activePuzzle[40] + activePuzzle[41]);
                        Label_Puzzle_R7.Text = Convert.ToString(activePuzzle[42] + activePuzzle[43] + activePuzzle[44] + activePuzzle[45] + activePuzzle[46] + activePuzzle[47] + activePuzzle[48]);

                        Label_Puzzle_C1.Text = Convert.ToString(activePuzzle[0] + activePuzzle[7] + activePuzzle[14] + activePuzzle[21] + activePuzzle[28] + activePuzzle[35] + activePuzzle[42]);
                        Label_Puzzle_C2.Text = Convert.ToString(activePuzzle[1] + activePuzzle[8] + activePuzzle[15] + activePuzzle[22] + activePuzzle[29] + activePuzzle[36] + activePuzzle[43]);
                        Label_Puzzle_C3.Text = Convert.ToString(activePuzzle[2] + activePuzzle[9] + activePuzzle[16] + activePuzzle[23] + activePuzzle[30] + activePuzzle[37] + activePuzzle[44]);
                        Label_Puzzle_C4.Text = Convert.ToString(activePuzzle[3] + activePuzzle[10] + activePuzzle[17] + activePuzzle[24] + activePuzzle[31] + activePuzzle[38] + activePuzzle[45]);
                        Label_Puzzle_C5.Text = Convert.ToString(activePuzzle[4] + activePuzzle[11] + activePuzzle[18] + activePuzzle[25] + activePuzzle[32] + activePuzzle[39] + activePuzzle[46]);
                        Label_Puzzle_C6.Text = Convert.ToString(activePuzzle[5] + activePuzzle[12] + activePuzzle[19] + activePuzzle[26] + activePuzzle[33] + activePuzzle[40] + activePuzzle[47]);
                        Label_Puzzle_C7.Text = Convert.ToString(activePuzzle[6] + activePuzzle[13] + activePuzzle[20] + activePuzzle[27] + activePuzzle[34] + activePuzzle[41] + activePuzzle[48]);

                        Label_Puzzle_D2.Text = Convert.ToString(activePuzzle[0] + activePuzzle[8] + activePuzzle[16] + activePuzzle[24] + activePuzzle[32] + activePuzzle[40] + activePuzzle[48]);
                        Label_Puzzle_D1.Text = Convert.ToString(activePuzzle[42] + activePuzzle[36] + activePuzzle[30] + activePuzzle[24] + activePuzzle[18] + activePuzzle[12] + activePuzzle[6]);

                        SumCheck();

                        break;
                }
            }

        }

        /* Fill Puzzle
         * 
         * */
        public void Fill_Puzzle()
        {
            if (activePuzzleNum != 100)
            {
                TextBoxReadOnly(false);
                switch (activePuzzle.Length)
                {

                    case 9:
                        //fill boxes
                        //row 1
                        if (activePuzzle[0] != 0)
                        {
                            Textbox_Puzzle_17.Text = Convert.ToString(activePuzzle[0]);

                            if (activePuzzle[0] == easyPuzzlesSolution[activePuzzleNum, 0])
                            {
                                Textbox_Puzzle_17.ReadOnly = true;
                            }
                        }

                        if (activePuzzle[1] != 0)
                        {
                            Textbox_Puzzle_18.Text = Convert.ToString(activePuzzle[1]);

                            if (activePuzzle[1] == easyPuzzlesSolution[activePuzzleNum, 1])
                            {
                                Textbox_Puzzle_18.ReadOnly = true;
                            }
                        }

                        if (activePuzzle[2] != 0)
                        {
                            Textbox_Puzzle_19.Text = Convert.ToString(activePuzzle[2]);

                            if (activePuzzle[2] == easyPuzzlesSolution[activePuzzleNum, 2])
                            {
                                Textbox_Puzzle_19.ReadOnly = true;
                            }
                        }
                        //row 2
                        if (activePuzzle[3] != 0)
                        {
                            Textbox_Puzzle_24.Text = Convert.ToString(activePuzzle[3]);

                            if (activePuzzle[3] == easyPuzzlesSolution[activePuzzleNum, 3])
                            {
                                Textbox_Puzzle_24.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[4] != 0)
                        {
                            Textbox_Puzzle_25.Text = Convert.ToString(activePuzzle[4]);

                            if (activePuzzle[4] == easyPuzzlesSolution[activePuzzleNum, 4])
                            {
                                Textbox_Puzzle_25.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[5] != 0)
                        {
                            Textbox_Puzzle_26.Text = Convert.ToString(activePuzzle[5]);

                            if (activePuzzle[5] == easyPuzzlesSolution[activePuzzleNum, 5])
                            {
                                Textbox_Puzzle_26.ReadOnly = true;
                            }
                        }
                        //row 3
                        if (activePuzzle[6] != 0)
                        {
                            Textbox_Puzzle_31.Text = Convert.ToString(activePuzzle[6]);

                            if (activePuzzle[6] == easyPuzzlesSolution[activePuzzleNum, 6])
                            {
                                Textbox_Puzzle_31.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[7] != 0)
                        {
                            Textbox_Puzzle_32.Text = Convert.ToString(activePuzzle[7]);

                            if (activePuzzle[7] == easyPuzzlesSolution[activePuzzleNum, 7])
                            {
                                Textbox_Puzzle_32.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[8] != 0)
                        {
                            Textbox_Puzzle_33.Text = Convert.ToString(activePuzzle[8]);

                            if (activePuzzle[8] == easyPuzzlesSolution[activePuzzleNum, 8])
                            {
                                Textbox_Puzzle_33.ReadOnly = true;
                            }
                        }
                        //correct sum labels
                        Label_Puzzle_Sum_R3.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 0] + easyPuzzlesSolution[activePuzzleNum, 1] + easyPuzzlesSolution[activePuzzleNum, 2]);
                        Label_Puzzle_Sum_R4.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 3] + easyPuzzlesSolution[activePuzzleNum, 4] + easyPuzzlesSolution[activePuzzleNum, 5]);
                        Label_Puzzle_Sum_R5.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 6] + easyPuzzlesSolution[activePuzzleNum, 7] + easyPuzzlesSolution[activePuzzleNum, 8]);

                        Label_Puzzle_Sum_C3.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 0] + easyPuzzlesSolution[activePuzzleNum, 3] + easyPuzzlesSolution[activePuzzleNum, 6]);
                        Label_Puzzle_Sum_C4.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 1] + easyPuzzlesSolution[activePuzzleNum, 4] + easyPuzzlesSolution[activePuzzleNum, 7]);
                        Label_Puzzle_Sum_C5.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 2] + easyPuzzlesSolution[activePuzzleNum, 5] + easyPuzzlesSolution[activePuzzleNum, 8]);

                        Label_Puzzle_Sum_D1.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 2] + easyPuzzlesSolution[activePuzzleNum, 4] + easyPuzzlesSolution[activePuzzleNum, 6]);
                        Label_Puzzle_Sum_D2.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 0] + easyPuzzlesSolution[activePuzzleNum, 4] + easyPuzzlesSolution[activePuzzleNum, 8]);

                        Update_Puzzle();

                        break;
                    //medium
                    case 25:
                        //row 1
                        if (activePuzzle[0] != 0)
                        {
                            Textbox_Puzzle_9.Text = Convert.ToString(activePuzzle[0]);

                            if (activePuzzle[0] == mediumPuzzlesSolution[activePuzzleNum, 0])
                            {
                                Textbox_Puzzle_9.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[1] != 0)
                        {
                            Textbox_Puzzle_10.Text = Convert.ToString(activePuzzle[1]);

                            if (activePuzzle[1] == mediumPuzzlesSolution[activePuzzleNum, 1])
                            {
                                Textbox_Puzzle_10.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[2] != 0)
                        {
                            Textbox_Puzzle_11.Text = Convert.ToString(activePuzzle[2]);

                            if (activePuzzle[2] == mediumPuzzlesSolution[activePuzzleNum, 2])
                            {
                                Textbox_Puzzle_11.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[3] != 0)
                        {
                            Textbox_Puzzle_12.Text = Convert.ToString(activePuzzle[3]);

                            if (activePuzzle[3] == mediumPuzzlesSolution[activePuzzleNum, 3])
                            {
                                Textbox_Puzzle_12.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[4] != 0)
                        {
                            Textbox_Puzzle_13.Text = Convert.ToString(activePuzzle[4]);

                            if (activePuzzle[4] == mediumPuzzlesSolution[activePuzzleNum, 4])
                            {
                                Textbox_Puzzle_13.ReadOnly = true;
                            }
                        }
                        //row 2
                        if (activePuzzle[5] != 0)
                        {
                            Textbox_Puzzle_16.Text = Convert.ToString(activePuzzle[5]);

                            if (activePuzzle[5] == mediumPuzzlesSolution[activePuzzleNum, 5])
                            {
                                Textbox_Puzzle_16.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[6] != 0)
                        {
                            Textbox_Puzzle_17.Text = Convert.ToString(activePuzzle[6]);

                            if (activePuzzle[6] == mediumPuzzlesSolution[activePuzzleNum, 6])
                            {
                                Textbox_Puzzle_17.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[7] != 0)
                        {
                            Textbox_Puzzle_18.Text = Convert.ToString(activePuzzle[7]);

                            if (activePuzzle[7] == mediumPuzzlesSolution[activePuzzleNum, 7])
                            {
                                Textbox_Puzzle_18.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[8] != 0)
                        {
                            Textbox_Puzzle_19.Text = Convert.ToString(activePuzzle[8]);

                            if (activePuzzle[8] == mediumPuzzlesSolution[activePuzzleNum, 8])
                            {
                                Textbox_Puzzle_19.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[9] != 0)
                        {
                            Textbox_Puzzle_20.Text = Convert.ToString(activePuzzle[9]);

                            if (activePuzzle[9] == mediumPuzzlesSolution[activePuzzleNum, 9])
                            {
                                Textbox_Puzzle_20.ReadOnly = true;
                            }
                        }
                        //row 3
                        if (activePuzzle[10] != 0)
                        {
                            Textbox_Puzzle_23.Text = Convert.ToString(activePuzzle[10]);

                            if (activePuzzle[10] == mediumPuzzlesSolution[activePuzzleNum, 10])
                            {
                                Textbox_Puzzle_23.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[11] != 0)
                        {
                            Textbox_Puzzle_24.Text = Convert.ToString(activePuzzle[11]);

                            if (activePuzzle[11] == mediumPuzzlesSolution[activePuzzleNum, 11])
                            {
                                Textbox_Puzzle_24.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[12] != 0)
                        {
                            Textbox_Puzzle_25.Text = Convert.ToString(activePuzzle[12]);

                            if (activePuzzle[12] == mediumPuzzlesSolution[activePuzzleNum, 12])
                            {
                                Textbox_Puzzle_25.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[13] != 0)
                        {
                            Textbox_Puzzle_26.Text = Convert.ToString(activePuzzle[13]);

                            if (activePuzzle[13] == mediumPuzzlesSolution[activePuzzleNum, 13])
                            {
                                Textbox_Puzzle_26.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[14] != 0)
                        {
                            Textbox_Puzzle_27.Text = Convert.ToString(activePuzzle[14]);

                            if (activePuzzle[14] == mediumPuzzlesSolution[activePuzzleNum, 14])
                            {
                                Textbox_Puzzle_27.ReadOnly = true;
                            }
                        }
                        //row 4
                        if (activePuzzle[15] != 0)
                        {
                            Textbox_Puzzle_30.Text = Convert.ToString(activePuzzle[15]);

                            if (activePuzzle[15] == mediumPuzzlesSolution[activePuzzleNum, 15])
                            {
                                Textbox_Puzzle_30.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[16] != 0)
                        {
                            Textbox_Puzzle_31.Text = Convert.ToString(activePuzzle[16]);

                            if (activePuzzle[16] == mediumPuzzlesSolution[activePuzzleNum, 16])
                            {
                                Textbox_Puzzle_31.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[17] != 0)
                        {
                            Textbox_Puzzle_32.Text = Convert.ToString(activePuzzle[17]);

                            if (activePuzzle[17] == mediumPuzzlesSolution[activePuzzleNum, 17])
                            {
                                Textbox_Puzzle_32.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[18] != 0)
                        {
                            Textbox_Puzzle_33.Text = Convert.ToString(activePuzzle[18]);

                            if (activePuzzle[18] == mediumPuzzlesSolution[activePuzzleNum, 18])
                            {
                                Textbox_Puzzle_33.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[19] != 0)
                        {
                            Textbox_Puzzle_34.Text = Convert.ToString(activePuzzle[19]);

                            if (activePuzzle[19] == mediumPuzzlesSolution[activePuzzleNum, 19])
                            {
                                Textbox_Puzzle_34.ReadOnly = true;
                            }
                        }
                        //row 5
                        if (activePuzzle[20] != 0)
                        {
                            Textbox_Puzzle_37.Text = Convert.ToString(activePuzzle[20]);

                            if (activePuzzle[20] == mediumPuzzlesSolution[activePuzzleNum, 20])
                            {
                                Textbox_Puzzle_37.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[21] != 0)
                        {
                            Textbox_Puzzle_38.Text = Convert.ToString(activePuzzle[21]);

                            if (activePuzzle[21] == mediumPuzzlesSolution[activePuzzleNum, 21])
                            {
                                Textbox_Puzzle_38.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[22] != 0)
                        {
                            Textbox_Puzzle_39.Text = Convert.ToString(activePuzzle[22]);

                            if (activePuzzle[22] == mediumPuzzlesSolution[activePuzzleNum, 22])
                            {
                                Textbox_Puzzle_39.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[23] != 0)
                        {
                            Textbox_Puzzle_40.Text = Convert.ToString(activePuzzle[23]);

                            if (activePuzzle[23] == mediumPuzzlesSolution[activePuzzleNum, 23])
                            {
                                Textbox_Puzzle_40.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[24] != 0)
                        {
                            Textbox_Puzzle_41.Text = Convert.ToString(activePuzzle[24]);

                            if (activePuzzle[24] == mediumPuzzlesSolution[activePuzzleNum, 24])
                            {
                                Textbox_Puzzle_41.ReadOnly = true;
                            }
                        }

                        //correct sum labels
                        Label_Puzzle_Sum_R2.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 0] + mediumPuzzlesSolution[activePuzzleNum, 1] + mediumPuzzlesSolution[activePuzzleNum, 2] + mediumPuzzlesSolution[activePuzzleNum, 3] + mediumPuzzlesSolution[activePuzzleNum, 4]);
                        Label_Puzzle_Sum_R3.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 5] + mediumPuzzlesSolution[activePuzzleNum, 6] + mediumPuzzlesSolution[activePuzzleNum, 7] + mediumPuzzlesSolution[activePuzzleNum, 8] + mediumPuzzlesSolution[activePuzzleNum, 9]);
                        Label_Puzzle_Sum_R4.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 10] + mediumPuzzlesSolution[activePuzzleNum, 11] + mediumPuzzlesSolution[activePuzzleNum, 12] + mediumPuzzlesSolution[activePuzzleNum, 13] + mediumPuzzlesSolution[activePuzzleNum, 14]);
                        Label_Puzzle_Sum_R5.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 15] + mediumPuzzlesSolution[activePuzzleNum, 16] + mediumPuzzlesSolution[activePuzzleNum, 17] + mediumPuzzlesSolution[activePuzzleNum, 18] + mediumPuzzlesSolution[activePuzzleNum, 19]);
                        Label_Puzzle_Sum_R6.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 20] + mediumPuzzlesSolution[activePuzzleNum, 21] + mediumPuzzlesSolution[activePuzzleNum, 22] + mediumPuzzlesSolution[activePuzzleNum, 23] + mediumPuzzlesSolution[activePuzzleNum, 24]);

                        Label_Puzzle_Sum_C2.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 0] + mediumPuzzlesSolution[activePuzzleNum, 5] + mediumPuzzlesSolution[activePuzzleNum, 10] + mediumPuzzlesSolution[activePuzzleNum, 15] + mediumPuzzlesSolution[activePuzzleNum, 20]);
                        Label_Puzzle_Sum_C3.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 1] + mediumPuzzlesSolution[activePuzzleNum, 6] + mediumPuzzlesSolution[activePuzzleNum, 11] + mediumPuzzlesSolution[activePuzzleNum, 16] + mediumPuzzlesSolution[activePuzzleNum, 21]);
                        Label_Puzzle_Sum_C4.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 2] + mediumPuzzlesSolution[activePuzzleNum, 7] + mediumPuzzlesSolution[activePuzzleNum, 12] + mediumPuzzlesSolution[activePuzzleNum, 17] + mediumPuzzlesSolution[activePuzzleNum, 22]);
                        Label_Puzzle_Sum_C5.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 3] + mediumPuzzlesSolution[activePuzzleNum, 8] + mediumPuzzlesSolution[activePuzzleNum, 13] + mediumPuzzlesSolution[activePuzzleNum, 18] + mediumPuzzlesSolution[activePuzzleNum, 23]);
                        Label_Puzzle_Sum_C6.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 4] + mediumPuzzlesSolution[activePuzzleNum, 9] + mediumPuzzlesSolution[activePuzzleNum, 14] + mediumPuzzlesSolution[activePuzzleNum, 19] + mediumPuzzlesSolution[activePuzzleNum, 24]);

                        Label_Puzzle_Sum_D2.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 0] + mediumPuzzlesSolution[activePuzzleNum, 6] + mediumPuzzlesSolution[activePuzzleNum, 12] + mediumPuzzlesSolution[activePuzzleNum, 18] + mediumPuzzlesSolution[activePuzzleNum, 24]);
                        Label_Puzzle_Sum_D1.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 20] + mediumPuzzlesSolution[activePuzzleNum, 16] + mediumPuzzlesSolution[activePuzzleNum, 12] + mediumPuzzlesSolution[activePuzzleNum, 8] + mediumPuzzlesSolution[activePuzzleNum, 4]);

                        Update_Puzzle();

                        break;
                    case 49:
                        //row 1
                        if (activePuzzle[0] != 0)
                        {
                            Textbox_Puzzle_1.Text = Convert.ToString(activePuzzle[0]);

                            if (activePuzzle[0] == hardPuzzlesSolution[activePuzzleNum, 0])
                            {
                                Textbox_Puzzle_1.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[1] != 0)
                        {
                            Textbox_Puzzle_2.Text = Convert.ToString(activePuzzle[1]);

                            if (activePuzzle[1] == hardPuzzlesSolution[activePuzzleNum, 1])
                            {
                                Textbox_Puzzle_2.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[2] != 0)
                        {
                            Textbox_Puzzle_3.Text = Convert.ToString(activePuzzle[2]);

                            if (activePuzzle[2] == hardPuzzlesSolution[activePuzzleNum, 2])
                            {
                                Textbox_Puzzle_3.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[3] != 0)
                        {
                            Textbox_Puzzle_4.Text = Convert.ToString(activePuzzle[3]);

                            if (activePuzzle[3] == hardPuzzlesSolution[activePuzzleNum, 3])
                            {
                                Textbox_Puzzle_4.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[4] != 0)
                        {
                            Textbox_Puzzle_5.Text = Convert.ToString(activePuzzle[4]);

                            if (activePuzzle[4] == hardPuzzlesSolution[activePuzzleNum, 4])
                            {
                                Textbox_Puzzle_5.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[5] != 0)
                        {
                            Textbox_Puzzle_6.Text = Convert.ToString(activePuzzle[5]);

                            if (activePuzzle[5] == hardPuzzlesSolution[activePuzzleNum, 5])
                            {
                                Textbox_Puzzle_6.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[6] != 0)
                        {
                            Textbox_Puzzle_7.Text = Convert.ToString(activePuzzle[6]);

                            if (activePuzzle[6] == hardPuzzlesSolution[activePuzzleNum, 6])
                            {
                                Textbox_Puzzle_7.ReadOnly = true;
                            }
                        }
                        //row 2
                        if (activePuzzle[7] != 0)
                        {
                            Textbox_Puzzle_8.Text = Convert.ToString(activePuzzle[7]);

                            if (activePuzzle[7] == hardPuzzlesSolution[activePuzzleNum, 7])
                            {
                                Textbox_Puzzle_8.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[8] != 0)
                        {
                            Textbox_Puzzle_9.Text = Convert.ToString(activePuzzle[8]);

                            if (activePuzzle[8] == hardPuzzlesSolution[activePuzzleNum, 8])
                            {
                                Textbox_Puzzle_9.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[9] != 0)
                        {
                            Textbox_Puzzle_10.Text = Convert.ToString(activePuzzle[9]);

                            if (activePuzzle[9] == hardPuzzlesSolution[activePuzzleNum, 9])
                            {
                                Textbox_Puzzle_10.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[10] != 0)
                        {
                            Textbox_Puzzle_11.Text = Convert.ToString(activePuzzle[10]);

                            if (activePuzzle[10] == hardPuzzlesSolution[activePuzzleNum, 10])
                            {
                                Textbox_Puzzle_11.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[11] != 0)
                        {
                            Textbox_Puzzle_12.Text = Convert.ToString(activePuzzle[11]);

                            if (activePuzzle[11] == hardPuzzlesSolution[activePuzzleNum, 11])
                            {
                                Textbox_Puzzle_12.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[12] != 0)
                        {
                            Textbox_Puzzle_13.Text = Convert.ToString(activePuzzle[12]);

                            if (activePuzzle[12] == hardPuzzlesSolution[activePuzzleNum, 12])
                            {
                                Textbox_Puzzle_13.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[13] != 0)
                        {
                            Textbox_Puzzle_14.Text = Convert.ToString(activePuzzle[13]);

                            if (activePuzzle[13] == hardPuzzlesSolution[activePuzzleNum, 13])
                            {
                                Textbox_Puzzle_14.ReadOnly = true;
                            }
                        }
                        //row 3
                        if (activePuzzle[14] != 0)
                        {
                            Textbox_Puzzle_15.Text = Convert.ToString(activePuzzle[14]);

                            if (activePuzzle[14] == hardPuzzlesSolution[activePuzzleNum, 14])
                            {
                                Textbox_Puzzle_15.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[15] != 0)
                        {
                            Textbox_Puzzle_16.Text = Convert.ToString(activePuzzle[15]);

                            if (activePuzzle[15] == hardPuzzlesSolution[activePuzzleNum, 15])
                            {
                                Textbox_Puzzle_16.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[16] != 0)
                        {
                            Textbox_Puzzle_17.Text = Convert.ToString(activePuzzle[16]);

                            if (activePuzzle[16] == hardPuzzlesSolution[activePuzzleNum, 16])
                            {
                                Textbox_Puzzle_17.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[17] != 0)
                        {
                            Textbox_Puzzle_18.Text = Convert.ToString(activePuzzle[17]);

                            if (activePuzzle[17] == hardPuzzlesSolution[activePuzzleNum, 17])
                            {
                                Textbox_Puzzle_18.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[18] != 0)
                        {
                            Textbox_Puzzle_19.Text = Convert.ToString(activePuzzle[18]);

                            if (activePuzzle[18] == hardPuzzlesSolution[activePuzzleNum, 18])
                            {
                                Textbox_Puzzle_19.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[19] != 0)
                        {
                            Textbox_Puzzle_20.Text = Convert.ToString(activePuzzle[19]);

                            if (activePuzzle[19] == hardPuzzlesSolution[activePuzzleNum, 19])
                            {
                                Textbox_Puzzle_20.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[20] != 0)
                        {
                            Textbox_Puzzle_21.Text = Convert.ToString(activePuzzle[20]);

                            if (activePuzzle[20] == hardPuzzlesSolution[activePuzzleNum, 20])
                            {
                                Textbox_Puzzle_21.ReadOnly = true;
                            }
                        }
                        //row 4
                        if (activePuzzle[21] != 0)
                        {
                            Textbox_Puzzle_22.Text = Convert.ToString(activePuzzle[21]);

                            if (activePuzzle[21] == hardPuzzlesSolution[activePuzzleNum, 21])
                            {
                                Textbox_Puzzle_22.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[22] != 0)
                        {
                            Textbox_Puzzle_23.Text = Convert.ToString(activePuzzle[22]);

                            if (activePuzzle[22] == hardPuzzlesSolution[activePuzzleNum, 22])
                            {
                                Textbox_Puzzle_23.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[23] != 0)
                        {
                            Textbox_Puzzle_24.Text = Convert.ToString(activePuzzle[23]);

                            if (activePuzzle[23] == hardPuzzlesSolution[activePuzzleNum, 23])
                            {
                                Textbox_Puzzle_24.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[24] != 0)
                        {
                            Textbox_Puzzle_25.Text = Convert.ToString(activePuzzle[24]);

                            if (activePuzzle[24] == hardPuzzlesSolution[activePuzzleNum, 24])
                            {
                                Textbox_Puzzle_25.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[25] != 0)
                        {
                            Textbox_Puzzle_26.Text = Convert.ToString(activePuzzle[25]);

                            if (activePuzzle[25] == hardPuzzlesSolution[activePuzzleNum, 25])
                            {
                                Textbox_Puzzle_26.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[26] != 0)
                        {
                            Textbox_Puzzle_27.Text = Convert.ToString(activePuzzle[26]);

                            if (activePuzzle[26] == hardPuzzlesSolution[activePuzzleNum, 26])
                            {
                                Textbox_Puzzle_27.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[27] != 0)
                        {
                            Textbox_Puzzle_28.Text = Convert.ToString(activePuzzle[27]);

                            if (activePuzzle[27] == hardPuzzlesSolution[activePuzzleNum, 27])
                            {
                                Textbox_Puzzle_28.ReadOnly = true;
                            }
                        }
                        //row 5
                        if (activePuzzle[28] != 0)
                        {
                            Textbox_Puzzle_29.Text = Convert.ToString(activePuzzle[28]);

                            if (activePuzzle[28] == hardPuzzlesSolution[activePuzzleNum, 28])
                            {
                                Textbox_Puzzle_29.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[29] != 0)
                        {
                            Textbox_Puzzle_30.Text = Convert.ToString(activePuzzle[29]);

                            if (activePuzzle[29] == hardPuzzlesSolution[activePuzzleNum, 29])
                            {
                                Textbox_Puzzle_30.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[30] != 0)
                        {
                            Textbox_Puzzle_31.Text = Convert.ToString(activePuzzle[30]);

                            if (activePuzzle[30] == hardPuzzlesSolution[activePuzzleNum, 30])
                            {
                                Textbox_Puzzle_31.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[31] != 0)
                        {
                            Textbox_Puzzle_32.Text = Convert.ToString(activePuzzle[31]);

                            if (activePuzzle[31] == hardPuzzlesSolution[activePuzzleNum, 31])
                            {
                                Textbox_Puzzle_32.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[32] != 0)
                        {
                            Textbox_Puzzle_33.Text = Convert.ToString(activePuzzle[32]);

                            if (activePuzzle[32] == hardPuzzlesSolution[activePuzzleNum, 32])
                            {
                                Textbox_Puzzle_33.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[33] != 0)
                        {
                            Textbox_Puzzle_34.Text = Convert.ToString(activePuzzle[33]);

                            if (activePuzzle[33] == hardPuzzlesSolution[activePuzzleNum, 33])
                            {
                                Textbox_Puzzle_34.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[34] != 0)
                        {
                            Textbox_Puzzle_35.Text = Convert.ToString(activePuzzle[34]);

                            if (activePuzzle[34] == hardPuzzlesSolution[activePuzzleNum, 34])
                            {
                                Textbox_Puzzle_35.ReadOnly = true;
                            }
                        }
                        //row 6
                        if (activePuzzle[35] != 0)
                        {
                            Textbox_Puzzle_36.Text = Convert.ToString(activePuzzle[35]);

                            if (activePuzzle[35] == hardPuzzlesSolution[activePuzzleNum, 35])
                            {
                                Textbox_Puzzle_36.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[36] != 0)
                        {
                            Textbox_Puzzle_37.Text = Convert.ToString(activePuzzle[36]);

                            if (activePuzzle[36] == hardPuzzlesSolution[activePuzzleNum, 36])
                            {
                                Textbox_Puzzle_37.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[37] != 0)
                        {
                            Textbox_Puzzle_38.Text = Convert.ToString(activePuzzle[37]);

                            if (activePuzzle[37] == hardPuzzlesSolution[activePuzzleNum, 37])
                            {
                                Textbox_Puzzle_38.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[38] != 0)
                        {
                            Textbox_Puzzle_39.Text = Convert.ToString(activePuzzle[38]);

                            if (activePuzzle[38] == hardPuzzlesSolution[activePuzzleNum, 38])
                            {
                                Textbox_Puzzle_39.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[39] != 0)
                        {
                            Textbox_Puzzle_40.Text = Convert.ToString(activePuzzle[39]);

                            if (activePuzzle[39] == hardPuzzlesSolution[activePuzzleNum, 39])
                            {
                                Textbox_Puzzle_40.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[40] != 0)
                        {
                            Textbox_Puzzle_41.Text = Convert.ToString(activePuzzle[40]);

                            if (activePuzzle[40] == hardPuzzlesSolution[activePuzzleNum, 40])
                            {
                                Textbox_Puzzle_41.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[41] != 0)
                        {
                            Textbox_Puzzle_42.Text = Convert.ToString(activePuzzle[41]);

                            if (activePuzzle[41] == hardPuzzlesSolution[activePuzzleNum, 41])
                            {
                                Textbox_Puzzle_42.ReadOnly = true;
                            }
                        }
                        //row 7
                        if (activePuzzle[42] != 0)
                        {
                            Textbox_Puzzle_43.Text = Convert.ToString(activePuzzle[42]);

                            if (activePuzzle[42] == hardPuzzlesSolution[activePuzzleNum, 42])
                            {
                                Textbox_Puzzle_43.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[43] != 0)
                        {
                            Textbox_Puzzle_44.Text = Convert.ToString(activePuzzle[43]);

                            if (activePuzzle[43] == hardPuzzlesSolution[activePuzzleNum, 43])
                            {
                                Textbox_Puzzle_44.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[44] != 0)
                        {
                            Textbox_Puzzle_45.Text = Convert.ToString(activePuzzle[44]);

                            if (activePuzzle[44] == hardPuzzlesSolution[activePuzzleNum, 44])
                            {
                                Textbox_Puzzle_45.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[45] != 0)
                        {
                            Textbox_Puzzle_46.Text = Convert.ToString(activePuzzle[45]);

                            if (activePuzzle[45] == hardPuzzlesSolution[activePuzzleNum, 45])
                            {
                                Textbox_Puzzle_46.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[46] != 0)
                        {
                            Textbox_Puzzle_47.Text = Convert.ToString(activePuzzle[46]);

                            if (activePuzzle[46] == hardPuzzlesSolution[activePuzzleNum, 46])
                            {
                                Textbox_Puzzle_47.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[47] != 0)
                        {
                            Textbox_Puzzle_48.Text = Convert.ToString(activePuzzle[47]);

                            if (activePuzzle[47] == hardPuzzlesSolution[activePuzzleNum, 47])
                            {
                                Textbox_Puzzle_48.ReadOnly = true;
                            }
                        }
                        if (activePuzzle[48] != 0)
                        {
                            Textbox_Puzzle_49.Text = Convert.ToString(activePuzzle[48]);

                            if (activePuzzle[48] == hardPuzzlesSolution[activePuzzleNum, 48])
                            {
                                Textbox_Puzzle_49.ReadOnly = true;
                            }
                        }

                        Label_Puzzle_Sum_R1.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 0] + hardPuzzlesSolution[activePuzzleNum, 1] + hardPuzzlesSolution[activePuzzleNum, 2] + hardPuzzlesSolution[activePuzzleNum, 3] + hardPuzzlesSolution[activePuzzleNum, 4] + hardPuzzlesSolution[activePuzzleNum, 5] + hardPuzzlesSolution[activePuzzleNum, 6]);
                        Label_Puzzle_Sum_R2.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 7] + hardPuzzlesSolution[activePuzzleNum, 8] + hardPuzzlesSolution[activePuzzleNum, 9] + hardPuzzlesSolution[activePuzzleNum, 10] + hardPuzzlesSolution[activePuzzleNum, 11] + hardPuzzlesSolution[activePuzzleNum, 12] + hardPuzzlesSolution[activePuzzleNum, 13]);
                        Label_Puzzle_Sum_R3.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 14] + hardPuzzlesSolution[activePuzzleNum, 15] + hardPuzzlesSolution[activePuzzleNum, 16] + hardPuzzlesSolution[activePuzzleNum, 17] + hardPuzzlesSolution[activePuzzleNum, 18] + hardPuzzlesSolution[activePuzzleNum, 19] + hardPuzzlesSolution[activePuzzleNum, 20]);
                        Label_Puzzle_Sum_R4.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 21] + hardPuzzlesSolution[activePuzzleNum, 22] + hardPuzzlesSolution[activePuzzleNum, 23] + hardPuzzlesSolution[activePuzzleNum, 24] + hardPuzzlesSolution[activePuzzleNum, 25] + hardPuzzlesSolution[activePuzzleNum, 26] + hardPuzzlesSolution[activePuzzleNum, 27]);
                        Label_Puzzle_Sum_R5.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 28] + hardPuzzlesSolution[activePuzzleNum, 29] + hardPuzzlesSolution[activePuzzleNum, 29] + hardPuzzlesSolution[activePuzzleNum, 30] + hardPuzzlesSolution[activePuzzleNum, 31] + hardPuzzlesSolution[activePuzzleNum, 32] + hardPuzzlesSolution[activePuzzleNum, 33]);
                        Label_Puzzle_Sum_R6.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 35] + hardPuzzlesSolution[activePuzzleNum, 36] + hardPuzzlesSolution[activePuzzleNum, 37] + hardPuzzlesSolution[activePuzzleNum, 38] + hardPuzzlesSolution[activePuzzleNum, 39] + hardPuzzlesSolution[activePuzzleNum, 40] + hardPuzzlesSolution[activePuzzleNum, 41]);
                        Label_Puzzle_Sum_R7.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 42] + hardPuzzlesSolution[activePuzzleNum, 43] + hardPuzzlesSolution[activePuzzleNum, 44] + hardPuzzlesSolution[activePuzzleNum, 45] + hardPuzzlesSolution[activePuzzleNum, 46] + hardPuzzlesSolution[activePuzzleNum, 47] + hardPuzzlesSolution[activePuzzleNum, 48]);

                        Label_Puzzle_Sum_C1.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 0] + hardPuzzlesSolution[activePuzzleNum, 7] + hardPuzzlesSolution[activePuzzleNum, 14] + hardPuzzlesSolution[activePuzzleNum, 21] + hardPuzzlesSolution[activePuzzleNum, 28] + hardPuzzlesSolution[activePuzzleNum, 35] + hardPuzzlesSolution[activePuzzleNum, 42]);
                        Label_Puzzle_Sum_C2.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 1] + hardPuzzlesSolution[activePuzzleNum, 8] + hardPuzzlesSolution[activePuzzleNum, 15] + hardPuzzlesSolution[activePuzzleNum, 22] + hardPuzzlesSolution[activePuzzleNum, 29] + hardPuzzlesSolution[activePuzzleNum, 36] + hardPuzzlesSolution[activePuzzleNum, 43]);
                        Label_Puzzle_Sum_C3.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 2] + hardPuzzlesSolution[activePuzzleNum, 9] + hardPuzzlesSolution[activePuzzleNum, 16] + hardPuzzlesSolution[activePuzzleNum, 23] + hardPuzzlesSolution[activePuzzleNum, 30] + hardPuzzlesSolution[activePuzzleNum, 37] + hardPuzzlesSolution[activePuzzleNum, 44]);
                        Label_Puzzle_Sum_C4.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 3] + hardPuzzlesSolution[activePuzzleNum, 10] + hardPuzzlesSolution[activePuzzleNum, 17] + hardPuzzlesSolution[activePuzzleNum, 24] + hardPuzzlesSolution[activePuzzleNum, 31] + hardPuzzlesSolution[activePuzzleNum, 38] + hardPuzzlesSolution[activePuzzleNum, 45]);
                        Label_Puzzle_Sum_C5.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 4] + hardPuzzlesSolution[activePuzzleNum, 11] + hardPuzzlesSolution[activePuzzleNum, 18] + hardPuzzlesSolution[activePuzzleNum, 25] + hardPuzzlesSolution[activePuzzleNum, 32] + hardPuzzlesSolution[activePuzzleNum, 39] + hardPuzzlesSolution[activePuzzleNum, 46]);
                        Label_Puzzle_Sum_C6.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 5] + hardPuzzlesSolution[activePuzzleNum, 12] + hardPuzzlesSolution[activePuzzleNum, 19] + hardPuzzlesSolution[activePuzzleNum, 26] + hardPuzzlesSolution[activePuzzleNum, 33] + hardPuzzlesSolution[activePuzzleNum, 40] + hardPuzzlesSolution[activePuzzleNum, 47]);
                        Label_Puzzle_Sum_C7.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 6] + hardPuzzlesSolution[activePuzzleNum, 13] + hardPuzzlesSolution[activePuzzleNum, 20] + hardPuzzlesSolution[activePuzzleNum, 27] + hardPuzzlesSolution[activePuzzleNum, 34] + hardPuzzlesSolution[activePuzzleNum, 41] + hardPuzzlesSolution[activePuzzleNum, 48]);

                        Label_Puzzle_Sum_D2.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 0] + hardPuzzlesSolution[activePuzzleNum, 8] + hardPuzzlesSolution[activePuzzleNum, 16] + hardPuzzlesSolution[activePuzzleNum, 24] + hardPuzzlesSolution[activePuzzleNum, 31] + hardPuzzlesSolution[activePuzzleNum, 40] + hardPuzzlesSolution[activePuzzleNum, 48]);
                        Label_Puzzle_Sum_D1.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 42] + hardPuzzlesSolution[activePuzzleNum, 36] + hardPuzzlesSolution[activePuzzleNum, 29] + hardPuzzlesSolution[activePuzzleNum, 24] + hardPuzzlesSolution[activePuzzleNum, 18] + hardPuzzlesSolution[activePuzzleNum, 36] + hardPuzzlesSolution[activePuzzleNum, 42]);
                        break;
                }
            }
            else
            {

                //nothing
            }

        }

        /*Choose Easy
         * Picks a random puzzle and calls the function to fill it in
         * */
        public void Choose_Easy()
        {
            uint randPuz = (uint)rand.Next(0, 3);
            bool flag = false;
            int j = 0;
            while (flag == false)
            {
                //check through all 
                if (randPuz == 0)
                    randPuz = 1;
                else if (randPuz == 1)
                    randPuz = 2;
                else if (randPuz == 2)
                    randPuz = 0;

                //check for completion
                for (int i = 0; i < easyPuzzlesSolution.GetLength(1); i++)
                {
                    if (easyPuzzlesProgress[randPuz, i] != easyPuzzlesSolution[randPuz, i])
                    {
                        flag = true;
                    }
                }

                j++;
                if (j == 7)
                {
                    flag = true;
                }
            }

            //if it did not go through every puzzle
            if (j != 7)
            {

                activePuzzle = new int[9];
                twoToOneArray(easyPuzzlesProgress, randPuz);
                activePuzzleNum = randPuz;
                Fill_Puzzle();
            }
            else
            {
                easyPuzzlesProgress = new int[3, 9];
                activePuzzle = new int[9];
                //oneToTwoArray(easyPuzzlesInitial, randPuz);
                twoToOneArray(easyPuzzlesProgress, randPuz);
                activePuzzleNum = randPuz;
                Fill_Puzzle();

            }
        }

        /*Choose Medium
         * Picks a random puzzle and calls the function to fill it in
         * */
        public void Choose_Medium()
        {
            uint randPuz = (uint)rand.Next(0, 3);
            bool flag = false;
            int j = 0;
            while (flag == false)
            {
                //check through all 
                if (randPuz == 0)
                    randPuz = 1;
                else if (randPuz == 1)
                    randPuz = 2;
                else if (randPuz == 2)
                    randPuz = 0;

                //check for completion
                for (int i = 0; i < mediumPuzzlesSolution.GetLength(1); i++)
                {
                    if (mediumPuzzlesProgress[randPuz, i] != mediumPuzzlesSolution[randPuz, i])
                    {
                        flag = true;
                    }
                }

                j++;
                if (j == 7)
                {
                    flag = true;
                }
            }
            //if it did not go through every puzzle
            if (j != 7)
            {

                activePuzzle = new int[25];
                twoToOneArray(mediumPuzzlesProgress, randPuz);
                activePuzzleNum = randPuz;
                Fill_Puzzle();
            }
            else
            {
                mediumPuzzlesProgress = new int[3, 25];
                activePuzzle = new int[25];
                //oneToTwoArray(mediumPuzzlesInitial, randPuz);
                twoToOneArray(mediumPuzzlesProgress, randPuz);
                activePuzzleNum = randPuz;
                Fill_Puzzle();

            }


        }

        /*Choose Hard
         * Picks a random puzzle and calls the function to fill it in
         * */
        public void Choose_Hard()
        {
            uint randPuz = (uint)rand.Next(0, 3);
            bool flag = false;
            int j = 0;
            while (flag == false)
            {
                //check through all 
                if (randPuz == 0)
                    randPuz = 1;
                else if (randPuz == 1)
                    randPuz = 2;
                else if (randPuz == 2)
                    randPuz = 0;

                //check for completion
                for (int i = 0; i < hardPuzzlesSolution.GetLength(1); i++)
                {
                    if (hardPuzzlesProgress[randPuz, i] != hardPuzzlesSolution[randPuz, i])
                    {
                        flag = true;
                    }
                }

                j++;
                if (j == 7)
                {
                    flag = true;
                }
            }
            //if it did not go through every puzzle
            if (j != 7)
            {

                activePuzzle = new int[49];
                twoToOneArray(hardPuzzlesProgress, randPuz);
                activePuzzleNum = randPuz;
                Fill_Puzzle();
            }
            else
            {
                mediumPuzzlesProgress = new int[3, 49];
                activePuzzle = new int[49];
                //oneToTwoArray(hardPuzzlesInitial, randPuz);
                twoToOneArray(hardPuzzlesProgress, randPuz);
                activePuzzleNum = randPuz;
                Fill_Puzzle();

            }
        }

        /* 2D array to 1D array
         * Copies an array from a 2D array into active array
         * */
        private void twoToOneArray(int[,] twoArray, uint pos)
        {
            if (twoArray.GetLength(1) == activePuzzle.Length)
            {
                for (int i = 0; i < twoArray.GetLength(1); i++)
                {
                    activePuzzle[i] = twoArray[pos, i];
                }
            }
        }
        /* 1D array to 2D array
         * Copies array from a active array into a 2D array
         * */
        private void oneToTwoArray(int[,] twoArray, uint pos)
        {
            if (twoArray.GetLength(1) == activePuzzle.Length)
            {
                for (int i = 0; i < twoArray.GetLength(1); i++)
                {
                    twoArray[pos, i] = activePuzzle[i];
                }
            }

        }

        /* SumCheck
         * updates colors of sums, if correct sum, changes color to green
         * if all correct, ends timer
         * */
        public void SumCheck()
        {
            //diagonals
            if (Label_Puzzle_D1.Text == Label_Puzzle_Sum_D1.Text)
                Label_Puzzle_D1.ForeColor = correctColor;
            else
                Label_Puzzle_D1.ForeColor = neutralColor;
            if (Label_Puzzle_D2.Text == Label_Puzzle_Sum_D2.Text)
                Label_Puzzle_D2.ForeColor = correctColor;
            else
                Label_Puzzle_D2.ForeColor = neutralColor;
            //rows
            if (Label_Puzzle_R1.Text == Label_Puzzle_Sum_R1.Text)
                Label_Puzzle_R1.ForeColor = correctColor;
            else
                Label_Puzzle_R1.ForeColor = neutralColor;
            if (Label_Puzzle_R2.Text == Label_Puzzle_Sum_R2.Text)
                Label_Puzzle_R2.ForeColor = correctColor;
            else
                Label_Puzzle_R2.ForeColor = neutralColor;
            if (Label_Puzzle_R3.Text == Label_Puzzle_Sum_R3.Text)
                Label_Puzzle_R3.ForeColor = correctColor;
            else
                Label_Puzzle_R3.ForeColor = neutralColor;
            if (Label_Puzzle_R4.Text == Label_Puzzle_Sum_R4.Text)
                Label_Puzzle_R4.ForeColor = correctColor;
            else
                Label_Puzzle_R4.ForeColor = neutralColor;
            if (Label_Puzzle_R5.Text == Label_Puzzle_Sum_R5.Text)
                Label_Puzzle_R5.ForeColor = correctColor;
            else
                Label_Puzzle_R5.ForeColor = neutralColor;
            if (Label_Puzzle_R6.Text == Label_Puzzle_Sum_R6.Text)
                Label_Puzzle_R6.ForeColor = correctColor;
            else
                Label_Puzzle_R6.ForeColor = neutralColor;
            if (Label_Puzzle_R7.Text == Label_Puzzle_Sum_R7.Text)
                Label_Puzzle_R7.ForeColor = correctColor;
            else
                Label_Puzzle_R7.ForeColor = neutralColor;

            //columns
            if (Label_Puzzle_C1.Text == Label_Puzzle_Sum_C1.Text)
                Label_Puzzle_C1.ForeColor = correctColor;
            else
                Label_Puzzle_C1.ForeColor = neutralColor;
            if (Label_Puzzle_C2.Text == Label_Puzzle_Sum_C2.Text)
                Label_Puzzle_C2.ForeColor = correctColor;
            else
                Label_Puzzle_C2.ForeColor = neutralColor;
            if (Label_Puzzle_C3.Text == Label_Puzzle_Sum_C3.Text)
                Label_Puzzle_C3.ForeColor = correctColor;
            else
                Label_Puzzle_C3.ForeColor = neutralColor;
            if (Label_Puzzle_C4.Text == Label_Puzzle_Sum_C4.Text)
                Label_Puzzle_C4.ForeColor = correctColor;
            else
                Label_Puzzle_C4.ForeColor = neutralColor;
            if (Label_Puzzle_C5.Text == Label_Puzzle_Sum_C5.Text)
                Label_Puzzle_C5.ForeColor = correctColor;
            else
                Label_Puzzle_C5.ForeColor = neutralColor;
            if (Label_Puzzle_C6.Text == Label_Puzzle_Sum_C6.Text)
                Label_Puzzle_C6.ForeColor = correctColor;
            else
                Label_Puzzle_C6.ForeColor = neutralColor;
            if (Label_Puzzle_C7.Text == Label_Puzzle_Sum_C7.Text)
                Label_Puzzle_C7.ForeColor = correctColor;
            else
                Label_Puzzle_C7.ForeColor = neutralColor;

            //easy check if all correct
            if (activePuzzle.Length == 9)
            {
                bool flag = true;
                for (int i = 0; i < activePuzzle.Length; i++)
                {
                    if (activePuzzle[i] != easyPuzzlesSolution[activePuzzleNum, i])
                    {
                        flag = false;
                    }
                }
                if (flag == true)
                {
                    //if they did not cheat
                    if (cheatFlag == false)
                    {
                        //puzzle complete
                        //save progress
                        oneToTwoArray(easyPuzzlesProgress, activePuzzleNum);
                        //stop timer
                        time.Stop();
                        Timer.Stop();
                        Button_Pause.Enabled = false;
                        Button_Cheat.Enabled = false;

                        easyTime.Add(time.ElapsedMilliseconds);
                        UpdateTime();
                        //inform user
                        MessageBox.Show(String.Format("You have completed the puzzle with a time of {0: 0.00}", time.ElapsedMilliseconds / (float)1000));

                        activePuzzle = new int[9];
                        activePuzzleNum = 100;
                    }
                    else
                    {
                        time.Stop();
                        Timer.Stop();

                        MessageBox.Show("Because of clicking cheat button, time not recorded.");
                        Button_Pause.Enabled = false;
                        Button_Cheat.Enabled = false;
                        activePuzzle = new int[9];
                        activePuzzleNum = 100;
                    }

                }

            }

            if (activePuzzle.Length == 25)
            {
                bool flag = true;
                for (int i = 0; i < activePuzzle.Length; i++)
                {
                    if (activePuzzle[i] != mediumPuzzlesSolution[activePuzzleNum, i])
                    {
                        flag = false;
                    }
                }
                if (flag == true)
                {
                    //if they did not cheat
                    if (cheatFlag == false)
                    {
                        //puzzle complete
                        //save progress
                        oneToTwoArray(mediumPuzzlesProgress, activePuzzleNum);
                        //stop timer
                        time.Stop();
                        Timer.Stop();
                        Button_Pause.Enabled = false;
                        Button_Cheat.Enabled = false;

                        mediumTime.Add(time.ElapsedMilliseconds);
                        UpdateTime();
                        //inform user
                        MessageBox.Show(String.Format("You have completed the puzzle with a time of {0: 0.00}", time.ElapsedMilliseconds / (float)1000));

                        activePuzzle = new int[9];
                        activePuzzleNum = 100;
                    }
                    else
                    {
                        time.Stop();
                        Timer.Stop();
                        MessageBox.Show("Because of clicking cheat button, time not recorded.");
                        Button_Pause.Enabled = false;
                        Button_Cheat.Enabled = false;

                        activePuzzle = new int[9];
                        activePuzzleNum = 100;
                    }

                }

            }

            if (activePuzzle.Length == 49)
            {
                bool flag = true;
                for (int i = 0; i < activePuzzle.Length; i++)
                {
                    if (activePuzzle[i] != hardPuzzlesSolution[activePuzzleNum, i])
                    {
                        flag = false;
                    }
                }
                if (flag == true)
                {
                    //if they did not cheat
                    if (cheatFlag == false)
                    {
                        //puzzle complete
                        //save progress
                        oneToTwoArray(hardPuzzlesProgress, activePuzzleNum);
                        //stop timer
                        time.Stop();
                        Timer.Stop();
                        Button_Pause.Enabled = false;
                        Button_Cheat.Enabled = false;

                        hardTime.Add(time.ElapsedMilliseconds);
                        UpdateTime();
                        //inform user
                        MessageBox.Show(String.Format("You have completed the puzzle with a time of {0: 0.00}", time.ElapsedMilliseconds / (float)1000));

                        activePuzzle = new int[9];
                        activePuzzleNum = 100;
                    }
                    else
                    {
                        time.Stop();
                        Timer.Stop();
                        MessageBox.Show("Because of clicking cheat button, time not recorded.");
                        Button_Pause.Enabled = false;
                        Button_Cheat.Enabled = false;

                        activePuzzle = new int[9];
                        activePuzzleNum = 100;
                    }

                }

            }

        }

        /* Update time
         * updates time labels
         * */
        private void UpdateTime()
        {
            if (activePuzzle.Length == 9)
            {
                Label_Fastest.Text = String.Format("Fastest Time: {0: 0.00}", easyTime.Max() / (float)1000);

                float average = 0;
                foreach (float f in easyTime)
                {
                    average += f;
                }
                average = average / easyTime.Count();

                Label_Average.Text = String.Format("Fastest Time: {0: 0.00}", average / (float)1000);
            }

            if (activePuzzle.Length == 25)
            {
                Label_Fastest.Text = String.Format("Fastest Time: {0: 0.00}", mediumTime.Max() / (float)1000);

                float average = 0;
                foreach (float f in easyTime)
                {
                    average += f;
                }
                average = average / mediumTime.Count();

                Label_Average.Text = String.Format("Fastest Time: {0: 0.00}", average / (float)1000);
            }

            if (activePuzzle.Length == 49)
            {
                Label_Fastest.Text = String.Format("Fastest Time: {0: 0.00}", hardTime.Max() / (float)1000);

                float average = 0;
                foreach (float f in hardTime)
                {
                    average += f;
                }
                average = average / mediumTime.Count();

                Label_Average.Text = String.Format("Fastest Time: {0: 0.00}", average / (float)1000);
            }

        }

        /*Reset Values
         * set all textboxes blank
         * */
        private void Reset_Values()
        {
            //clear everything
            Textbox_Puzzle_1.Clear();
            Textbox_Puzzle_2.Clear();
            Textbox_Puzzle_3.Clear();
            Textbox_Puzzle_4.Clear();
            Textbox_Puzzle_5.Clear();
            Textbox_Puzzle_6.Clear();
            Textbox_Puzzle_7.Clear();
            Textbox_Puzzle_8.Clear();
            Textbox_Puzzle_9.Clear();
            Textbox_Puzzle_10.Clear();
            Textbox_Puzzle_11.Clear();
            Textbox_Puzzle_12.Clear();
            Textbox_Puzzle_13.Clear();
            Textbox_Puzzle_14.Clear();
            Textbox_Puzzle_15.Clear();
            Textbox_Puzzle_16.Clear();
            Textbox_Puzzle_17.Clear();
            Textbox_Puzzle_18.Clear();
            Textbox_Puzzle_19.Clear();
            Textbox_Puzzle_20.Clear();
            Textbox_Puzzle_21.Clear();
            Textbox_Puzzle_22.Clear();
            Textbox_Puzzle_23.Clear();
            Textbox_Puzzle_24.Clear();
            Textbox_Puzzle_25.Clear();
            Textbox_Puzzle_26.Clear();
            Textbox_Puzzle_27.Clear();
            Textbox_Puzzle_28.Clear();
            Textbox_Puzzle_29.Clear();
            Textbox_Puzzle_30.Clear();
            Textbox_Puzzle_31.Clear();
            Textbox_Puzzle_32.Clear();
            Textbox_Puzzle_33.Clear();
            Textbox_Puzzle_34.Clear();
            Textbox_Puzzle_35.Clear();
            Textbox_Puzzle_36.Clear();
            Textbox_Puzzle_37.Clear();
            Textbox_Puzzle_38.Clear();
            Textbox_Puzzle_39.Clear();
            Textbox_Puzzle_40.Clear();
            Textbox_Puzzle_41.Clear();

            TextBoxReadOnly(false);
        }

        /* Set Difficulty
         * 0 = Easy, 1 = Medium, 2 = Hard
         * */
        private void Set_Difficulty(uint difficulty)
        {
            //default to easy
            bool aSize = false;
            bool bSize = false;

            //row and column offsets
            /*              C
             *              B
             *              A
             *              A
             *              A
             *              B
             *              C
             * C B A A A B C
             * */
            int rowOffsetA = -110;
            int rowOffsetB = -1000;
            int rowOffsetC = -1000;

            int colOffsetA = -110;
            int colOffsetB = -1000;
            int colOffsetC = -1000;

            //medium
            if (difficulty >= 1)
            {
                bSize = true;
                rowOffsetA = -50;
                rowOffsetB = -50;
                rowOffsetC = -1000;

                colOffsetA = -50;
                colOffsetB = -50;
                colOffsetC = -1000;
            }
            //hard
            if (difficulty == 2)
            {
                aSize = true;
                rowOffsetA = 0;
                rowOffsetB = 0;
                rowOffsetC = 0;

                colOffsetA = 0;
                colOffsetB = 0;
                colOffsetC = 0;
            }

            //Hard Only
            //row 1
            Textbox_Puzzle_1.Visible = aSize;
            Textbox_Puzzle_2.Visible = aSize;
            Textbox_Puzzle_3.Visible = aSize;
            Textbox_Puzzle_4.Visible = aSize;
            Textbox_Puzzle_5.Visible = aSize;
            Textbox_Puzzle_6.Visible = aSize;
            Textbox_Puzzle_7.Visible = aSize;
            //row 2
            Textbox_Puzzle_8.Visible = aSize;
            Textbox_Puzzle_14.Visible = aSize;
            //row 3
            Textbox_Puzzle_15.Visible = aSize;
            Textbox_Puzzle_21.Visible = aSize;
            //row 4
            Textbox_Puzzle_22.Visible = aSize;
            Textbox_Puzzle_28.Visible = aSize;
            //row 5
            Textbox_Puzzle_29.Visible = aSize;
            Textbox_Puzzle_35.Visible = aSize;
            //row 6
            Textbox_Puzzle_36.Visible = aSize;
            Textbox_Puzzle_42.Visible = aSize;
            //row 7
            Textbox_Puzzle_43.Visible = aSize;
            Textbox_Puzzle_44.Visible = aSize;
            Textbox_Puzzle_45.Visible = aSize;
            Textbox_Puzzle_46.Visible = aSize;
            Textbox_Puzzle_47.Visible = aSize;
            Textbox_Puzzle_48.Visible = aSize;
            Textbox_Puzzle_49.Visible = aSize;


            //Medium Only
            //row 2
            Textbox_Puzzle_9.Visible = bSize;
            Textbox_Puzzle_10.Visible = bSize;
            Textbox_Puzzle_11.Visible = bSize;
            Textbox_Puzzle_12.Visible = bSize;
            Textbox_Puzzle_13.Visible = bSize;
            //row 3
            Textbox_Puzzle_16.Visible = bSize;
            Textbox_Puzzle_20.Visible = bSize;
            //row 4
            Textbox_Puzzle_23.Visible = bSize;
            Textbox_Puzzle_27.Visible = bSize;
            //row 5
            Textbox_Puzzle_30.Visible = bSize;
            Textbox_Puzzle_34.Visible = bSize;
            //row 6
            Textbox_Puzzle_37.Visible = bSize;
            Textbox_Puzzle_38.Visible = bSize;
            Textbox_Puzzle_39.Visible = bSize;
            Textbox_Puzzle_40.Visible = bSize;
            Textbox_Puzzle_41.Visible = bSize;


            //Sum Labels
            //row labels
            Label_Puzzle_R1.Location = new System.Drawing.Point(386 + rowOffsetC, 145);
            Label_Puzzle_R2.Location = new System.Drawing.Point(386 + rowOffsetB, 200);
            Label_Puzzle_R3.Location = new System.Drawing.Point(386 + rowOffsetA, 255);
            Label_Puzzle_R4.Location = new System.Drawing.Point(386 + rowOffsetA, 310);
            Label_Puzzle_R5.Location = new System.Drawing.Point(386 + rowOffsetA, 365);
            Label_Puzzle_R6.Location = new System.Drawing.Point(386 + rowOffsetB, 420);
            Label_Puzzle_R7.Location = new System.Drawing.Point(386 + rowOffsetC, 475);
            //row sum labels
            Label_Puzzle_Sum_R1.Location = new System.Drawing.Point(419 + rowOffsetC, 145);
            Label_Puzzle_Sum_R2.Location = new System.Drawing.Point(419 + rowOffsetB, 200);
            Label_Puzzle_Sum_R3.Location = new System.Drawing.Point(419 + rowOffsetA, 255);
            Label_Puzzle_Sum_R4.Location = new System.Drawing.Point(419 + rowOffsetA, 310);
            Label_Puzzle_Sum_R5.Location = new System.Drawing.Point(419 + rowOffsetA, 365);
            Label_Puzzle_Sum_R6.Location = new System.Drawing.Point(419 + rowOffsetB, 420);
            Label_Puzzle_Sum_R7.Location = new System.Drawing.Point(419 + rowOffsetC, 475);
            //diagonal labels
            Label_Puzzle_D1.Location = new System.Drawing.Point(386 + rowOffsetA, 109 + Math.Abs(colOffsetA));
            Label_Puzzle_D2.Location = new System.Drawing.Point(386 + rowOffsetA, 523 + colOffsetA);
            //diagonal sum labels
            Label_Puzzle_Sum_D1.Location = new System.Drawing.Point(419 + rowOffsetA, 88 + Math.Abs(colOffsetA));
            Label_Puzzle_Sum_D2.Location = new System.Drawing.Point(419 + rowOffsetA, 538 + colOffsetA);
            //column labels
            Label_Puzzle_C1.Location = new System.Drawing.Point(15, 523 + colOffsetC);
            Label_Puzzle_C2.Location = new System.Drawing.Point(67, 523 + colOffsetB);
            Label_Puzzle_C3.Location = new System.Drawing.Point(120, 523 + colOffsetA);
            Label_Puzzle_C4.Location = new System.Drawing.Point(173, 523 + colOffsetA);
            Label_Puzzle_C5.Location = new System.Drawing.Point(226, 523 + colOffsetA);
            Label_Puzzle_C6.Location = new System.Drawing.Point(279, 523 + colOffsetB);
            Label_Puzzle_C7.Location = new System.Drawing.Point(332, 523 + colOffsetC);
            //column sum labels
            Label_Puzzle_Sum_C1.Location = new System.Drawing.Point(15, 552 + colOffsetC);
            Label_Puzzle_Sum_C2.Location = new System.Drawing.Point(67, 552 + colOffsetB);
            Label_Puzzle_Sum_C3.Location = new System.Drawing.Point(120, 552 + colOffsetA);
            Label_Puzzle_Sum_C4.Location = new System.Drawing.Point(173, 552 + colOffsetA);
            Label_Puzzle_Sum_C5.Location = new System.Drawing.Point(226, 552 + colOffsetA);
            Label_Puzzle_Sum_C6.Location = new System.Drawing.Point(279, 552 + colOffsetB);
            Label_Puzzle_Sum_C7.Location = new System.Drawing.Point(332, 552 + colOffsetC);


        }

        /* Textbox Puzzle KeyPress
         * only allow numbers to be input
         * */
        private void Textbox_Puzzle_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if it is a control character or a digit, allow input
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }

            if (e.KeyChar == '0')
            {
                e.KeyChar = '\0';
            }



        }

        /* Textbox Puzzle Text Change
         * Occurs when text changes on any textbox, updates puzzle
         * 
         * */
        private void Textbox_Puzzle_TextChanged(object sender, EventArgs e)
        {
            Update_Puzzle();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            switch (activePuzzle.Length)
            {
                case 9:
                    Label_Timer.Text = String.Format("{0: 0.00}", (time.ElapsedMilliseconds + (float)easyTimeArray[activePuzzleNum]) / (float)1000);
                    break;
                case 25:
                    Label_Timer.Text = String.Format("{0: 0.00}", (time.ElapsedMilliseconds + (float)mediumTimeArray[activePuzzleNum]) / (float)1000);
                    break;
                case 49:
                    Label_Timer.Text = String.Format("{0: 0.00}", (time.ElapsedMilliseconds + (float)hardTimeArray[activePuzzleNum]) / (float)1000);
                    break;
            }

        }

        private void Button_Pause_Click(object sender, EventArgs e)
        {
            if (Button_Pause.Text == "Pause")
            {
                Timer.Stop();
                time.Stop();
                Button_Pause.Text = "Resume";
                Label_Paused.Text = "?";
                TextBoxReadOnly(true);
            }
            else if (Button_Pause.Text == "Resume")
            {
                Timer.Start();
                time.Start();
                Button_Pause.Text = "Pause";
                Label_Paused.Text = "";
                TextBoxReadOnly(false);
            }

        }

        /* TextBoxReadonly
         * sets all textboxes to readonly state input
         * */
        private void TextBoxReadOnly(bool textbox)
        {
            Textbox_Puzzle_1.ReadOnly = textbox;
            Textbox_Puzzle_2.ReadOnly = textbox;
            Textbox_Puzzle_3.ReadOnly = textbox;
            Textbox_Puzzle_4.ReadOnly = textbox;
            Textbox_Puzzle_5.ReadOnly = textbox;
            Textbox_Puzzle_6.ReadOnly = textbox;
            Textbox_Puzzle_7.ReadOnly = textbox;
            Textbox_Puzzle_8.ReadOnly = textbox;
            Textbox_Puzzle_9.ReadOnly = textbox;
            Textbox_Puzzle_10.ReadOnly = textbox;
            Textbox_Puzzle_11.ReadOnly = textbox;
            Textbox_Puzzle_12.ReadOnly = textbox;
            Textbox_Puzzle_13.ReadOnly = textbox;
            Textbox_Puzzle_14.ReadOnly = textbox;
            Textbox_Puzzle_15.ReadOnly = textbox;
            Textbox_Puzzle_16.ReadOnly = textbox;
            Textbox_Puzzle_17.ReadOnly = textbox;
            Textbox_Puzzle_18.ReadOnly = textbox;
            Textbox_Puzzle_19.ReadOnly = textbox;
            Textbox_Puzzle_20.ReadOnly = textbox;
            Textbox_Puzzle_21.ReadOnly = textbox;
            Textbox_Puzzle_22.ReadOnly = textbox;
            Textbox_Puzzle_23.ReadOnly = textbox;
            Textbox_Puzzle_24.ReadOnly = textbox;
            Textbox_Puzzle_25.ReadOnly = textbox;
            Textbox_Puzzle_26.ReadOnly = textbox;
            Textbox_Puzzle_27.ReadOnly = textbox;
            Textbox_Puzzle_28.ReadOnly = textbox;
            Textbox_Puzzle_29.ReadOnly = textbox;
            Textbox_Puzzle_30.ReadOnly = textbox;
            Textbox_Puzzle_31.ReadOnly = textbox;
            Textbox_Puzzle_32.ReadOnly = textbox;
            Textbox_Puzzle_33.ReadOnly = textbox;
            Textbox_Puzzle_34.ReadOnly = textbox;
            Textbox_Puzzle_35.ReadOnly = textbox;
            Textbox_Puzzle_36.ReadOnly = textbox;
            Textbox_Puzzle_37.ReadOnly = textbox;
            Textbox_Puzzle_38.ReadOnly = textbox;
            Textbox_Puzzle_39.ReadOnly = textbox;
            Textbox_Puzzle_40.ReadOnly = textbox;
            Textbox_Puzzle_41.ReadOnly = textbox;
        }

        /* Cheat button
         * 
         * */
        private void Button_Cheat_Click(object sender, EventArgs e)
        {
            cheatFlag = true;

            bool flag = false;
            switch (activePuzzle.Length)
            {

                case 9:
                    if (Textbox_Puzzle_25.Text == "" || Convert.ToInt32(Textbox_Puzzle_25.Text) != easyPuzzlesSolution[activePuzzleNum, 4])
                    {
                        Textbox_Puzzle_25.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 4]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_31.Text == "" || Convert.ToInt32(Textbox_Puzzle_31.Text) != easyPuzzlesSolution[activePuzzleNum, 6])
                    {
                        Textbox_Puzzle_31.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 6]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_19.Text == "" || Convert.ToInt32(Textbox_Puzzle_19.Text) != easyPuzzlesSolution[activePuzzleNum, 2])
                    {
                        Textbox_Puzzle_19.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 2]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_24.Text == "" || Convert.ToInt32(Textbox_Puzzle_24.Text) != easyPuzzlesSolution[activePuzzleNum, 3])
                    {
                        Textbox_Puzzle_24.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 3]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_32.Text == "" || Convert.ToInt32(Textbox_Puzzle_32.Text) != easyPuzzlesSolution[activePuzzleNum, 7])
                    {
                        Textbox_Puzzle_32.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 7]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_26.Text == "" || Convert.ToInt32(Textbox_Puzzle_26.Text) != easyPuzzlesSolution[activePuzzleNum, 5])
                    {
                        Textbox_Puzzle_26.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 5]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_17.Text == "" || Convert.ToInt32(Textbox_Puzzle_17.Text) != easyPuzzlesSolution[activePuzzleNum, 0])
                    {
                        Textbox_Puzzle_17.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 0]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_33.Text == "" || Convert.ToInt32(Textbox_Puzzle_33.Text) != easyPuzzlesSolution[activePuzzleNum, 8])
                    {
                        Textbox_Puzzle_33.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 8]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_18.Text == "" || Convert.ToInt32(Textbox_Puzzle_18.Text) != easyPuzzlesSolution[activePuzzleNum, 1])
                    {
                        Textbox_Puzzle_18.Text = Convert.ToString(easyPuzzlesSolution[activePuzzleNum, 1]);
                        flag = true;
                        return;
                    }



                    break;

                case 25:

                    if (Textbox_Puzzle_16.Text == "" || Convert.ToInt32(Textbox_Puzzle_16.Text) != mediumPuzzlesSolution[activePuzzleNum, 5])
                    {
                        Textbox_Puzzle_16.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 5]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_33.Text == "" || Convert.ToInt32(Textbox_Puzzle_33.Text) != mediumPuzzlesSolution[activePuzzleNum, 18])
                    {
                        Textbox_Puzzle_33.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 18]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_34.Text == "" || Convert.ToInt32(Textbox_Puzzle_34.Text) != mediumPuzzlesSolution[activePuzzleNum, 19])
                    {
                        Textbox_Puzzle_34.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 19]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_37.Text == "" || Convert.ToInt32(Textbox_Puzzle_37.Text) != mediumPuzzlesSolution[activePuzzleNum, 20])
                    {
                        Textbox_Puzzle_37.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 20]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_17.Text == "" || Convert.ToInt32(Textbox_Puzzle_17.Text) != mediumPuzzlesSolution[activePuzzleNum, 6])
                    {
                        Textbox_Puzzle_17.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 6]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_18.Text == "" || Convert.ToInt32(Textbox_Puzzle_18.Text) != mediumPuzzlesSolution[activePuzzleNum, 7])
                    {
                        Textbox_Puzzle_18.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 7]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_19.Text == "" || Convert.ToInt32(Textbox_Puzzle_19.Text) != mediumPuzzlesSolution[activePuzzleNum, 8])
                    {
                        Textbox_Puzzle_19.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 8]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_20.Text == "" || Convert.ToInt32(Textbox_Puzzle_20.Text) != mediumPuzzlesSolution[activePuzzleNum, 9])
                    {
                        Textbox_Puzzle_20.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 9]);
                        flag = true;
                        return;
                    }

                    if (Textbox_Puzzle_23.Text == "" || Convert.ToInt32(Textbox_Puzzle_23.Text) != mediumPuzzlesSolution[activePuzzleNum, 10])
                    {
                        Textbox_Puzzle_23.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 10]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_24.Text == "" || Convert.ToInt32(Textbox_Puzzle_24.Text) != mediumPuzzlesSolution[activePuzzleNum, 11])
                    {
                        Textbox_Puzzle_24.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 11]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_25.Text == "" || Convert.ToInt32(Textbox_Puzzle_25.Text) != mediumPuzzlesSolution[activePuzzleNum, 12])
                    {
                        Textbox_Puzzle_25.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 12]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_26.Text == "" || Convert.ToInt32(Textbox_Puzzle_26.Text) != mediumPuzzlesSolution[activePuzzleNum, 13])
                    {
                        Textbox_Puzzle_26.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 13]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_27.Text == "" || Convert.ToInt32(Textbox_Puzzle_27.Text) != mediumPuzzlesSolution[activePuzzleNum, 14])
                    {
                        Textbox_Puzzle_27.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 14]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_41.Text == "" || Convert.ToInt32(Textbox_Puzzle_41.Text) != mediumPuzzlesSolution[activePuzzleNum, 24])
                    {
                        Textbox_Puzzle_41.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 24]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_32.Text == "" || Convert.ToInt32(Textbox_Puzzle_32.Text) != mediumPuzzlesSolution[activePuzzleNum, 17])
                    {
                        Textbox_Puzzle_32.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 17]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_30.Text == "" || Convert.ToInt32(Textbox_Puzzle_30.Text) != mediumPuzzlesSolution[activePuzzleNum, 15])
                    {
                        Textbox_Puzzle_30.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 15]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_9.Text == "" || Convert.ToInt32(Textbox_Puzzle_9.Text) != mediumPuzzlesSolution[activePuzzleNum, 0])
                    {
                        Textbox_Puzzle_9.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 0]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_10.Text == "" || Convert.ToInt32(Textbox_Puzzle_10.Text) != mediumPuzzlesSolution[activePuzzleNum, 1])
                    {
                        Textbox_Puzzle_10.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 1]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_11.Text == "" || Convert.ToInt32(Textbox_Puzzle_11.Text) != mediumPuzzlesSolution[activePuzzleNum, 2])
                    {
                        Textbox_Puzzle_11.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 2]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_12.Text == "" || Convert.ToInt32(Textbox_Puzzle_12.Text) != mediumPuzzlesSolution[activePuzzleNum, 3])
                    {
                        Textbox_Puzzle_12.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 3]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_13.Text == "" || Convert.ToInt32(Textbox_Puzzle_13.Text) != mediumPuzzlesSolution[activePuzzleNum, 4])
                    {
                        Textbox_Puzzle_13.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 4]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_31.Text == "" || Convert.ToInt32(Textbox_Puzzle_31.Text) != mediumPuzzlesSolution[activePuzzleNum, 16])
                    {
                        Textbox_Puzzle_31.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 16]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_38.Text == "" || Convert.ToInt32(Textbox_Puzzle_38.Text) != mediumPuzzlesSolution[activePuzzleNum, 21])
                    {
                        Textbox_Puzzle_38.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 21]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_39.Text == "" || Convert.ToInt32(Textbox_Puzzle_39.Text) != mediumPuzzlesSolution[activePuzzleNum, 22])
                    {
                        Textbox_Puzzle_39.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 22]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_40.Text == "" || Convert.ToInt32(Textbox_Puzzle_40.Text) != mediumPuzzlesSolution[activePuzzleNum, 23])
                    {
                        Textbox_Puzzle_40.Text = Convert.ToString(mediumPuzzlesSolution[activePuzzleNum, 23]);
                        flag = true;
                        return;
                    }


                    break;
                case 49:
                    if (Textbox_Puzzle_1.Text == "" || Convert.ToInt32(Textbox_Puzzle_1.Text) != hardPuzzlesSolution[activePuzzleNum, 0])
                    {
                        Textbox_Puzzle_1.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 0]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_2.Text == "" || Convert.ToInt32(Textbox_Puzzle_2.Text) != hardPuzzlesSolution[activePuzzleNum, 1])
                    {
                        Textbox_Puzzle_2.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 1]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_3.Text == "" || Convert.ToInt32(Textbox_Puzzle_3.Text) != hardPuzzlesSolution[activePuzzleNum, 2])
                    {
                        Textbox_Puzzle_3.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 2]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_4.Text == "" || Convert.ToInt32(Textbox_Puzzle_4.Text) != hardPuzzlesSolution[activePuzzleNum, 3])
                    {
                        Textbox_Puzzle_4.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 3]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_5.Text == "" || Convert.ToInt32(Textbox_Puzzle_5.Text) != hardPuzzlesSolution[activePuzzleNum, 4])
                    {
                        Textbox_Puzzle_5.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 4]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_6.Text == "" || Convert.ToInt32(Textbox_Puzzle_6.Text) != hardPuzzlesSolution[activePuzzleNum, 5])
                    {
                        Textbox_Puzzle_6.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 5]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_7.Text == "" || Convert.ToInt32(Textbox_Puzzle_7.Text) != hardPuzzlesSolution[activePuzzleNum, 6])
                    {
                        Textbox_Puzzle_7.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 6]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_8.Text == "" || Convert.ToInt32(Textbox_Puzzle_8.Text) != hardPuzzlesSolution[activePuzzleNum, 7])
                    {
                        Textbox_Puzzle_8.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 7]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_9.Text == "" || Convert.ToInt32(Textbox_Puzzle_9.Text) != hardPuzzlesSolution[activePuzzleNum, 8])
                    {
                        Textbox_Puzzle_9.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 8]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_10.Text == "" || Convert.ToInt32(Textbox_Puzzle_10.Text) != hardPuzzlesSolution[activePuzzleNum, 9])
                    {
                        Textbox_Puzzle_10.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 9]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_11.Text == "" || Convert.ToInt32(Textbox_Puzzle_11.Text) != hardPuzzlesSolution[activePuzzleNum, 10])
                    {
                        Textbox_Puzzle_11.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 10]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_12.Text == "" || Convert.ToInt32(Textbox_Puzzle_12.Text) != hardPuzzlesSolution[activePuzzleNum, 11])
                    {
                        Textbox_Puzzle_12.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 11]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_13.Text == "" || Convert.ToInt32(Textbox_Puzzle_13.Text) != hardPuzzlesSolution[activePuzzleNum, 12])
                    {
                        Textbox_Puzzle_13.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 12]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_14.Text == "" || Convert.ToInt32(Textbox_Puzzle_14.Text) != hardPuzzlesSolution[activePuzzleNum, 13])
                    {
                        Textbox_Puzzle_14.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 13]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_15.Text == "" || Convert.ToInt32(Textbox_Puzzle_15.Text) != hardPuzzlesSolution[activePuzzleNum, 14])
                    {
                        Textbox_Puzzle_15.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 14]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_16.Text == "" || Convert.ToInt32(Textbox_Puzzle_16.Text) != hardPuzzlesSolution[activePuzzleNum, 15])
                    {
                        Textbox_Puzzle_16.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 15]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_17.Text == "" || Convert.ToInt32(Textbox_Puzzle_17.Text) != hardPuzzlesSolution[activePuzzleNum, 16])
                    {
                        Textbox_Puzzle_17.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 16]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_18.Text == "" || Convert.ToInt32(Textbox_Puzzle_18.Text) != hardPuzzlesSolution[activePuzzleNum, 17])
                    {
                        Textbox_Puzzle_18.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 17]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_19.Text == "" || Convert.ToInt32(Textbox_Puzzle_19.Text) != hardPuzzlesSolution[activePuzzleNum, 18])
                    {
                        Textbox_Puzzle_19.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 18]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_20.Text == "" || Convert.ToInt32(Textbox_Puzzle_20.Text) != hardPuzzlesSolution[activePuzzleNum, 19])
                    {
                        Textbox_Puzzle_20.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 19]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_21.Text == "" || Convert.ToInt32(Textbox_Puzzle_21.Text) != hardPuzzlesSolution[activePuzzleNum, 20])
                    {
                        Textbox_Puzzle_21.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 20]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_22.Text == "" || Convert.ToInt32(Textbox_Puzzle_22.Text) != hardPuzzlesSolution[activePuzzleNum, 21])
                    {
                        Textbox_Puzzle_22.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 21]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_23.Text == "" || Convert.ToInt32(Textbox_Puzzle_23.Text) != hardPuzzlesSolution[activePuzzleNum, 22])
                    {
                        Textbox_Puzzle_23.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 22]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_24.Text == "" || Convert.ToInt32(Textbox_Puzzle_24.Text) != hardPuzzlesSolution[activePuzzleNum, 23])
                    {
                        Textbox_Puzzle_24.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 23]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_25.Text == "" || Convert.ToInt32(Textbox_Puzzle_25.Text) != hardPuzzlesSolution[activePuzzleNum, 24])
                    {
                        Textbox_Puzzle_25.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 24]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_26.Text == "" || Convert.ToInt32(Textbox_Puzzle_26.Text) != hardPuzzlesSolution[activePuzzleNum, 25])
                    {
                        Textbox_Puzzle_26.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 25]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_27.Text == "" || Convert.ToInt32(Textbox_Puzzle_27.Text) != hardPuzzlesSolution[activePuzzleNum, 26])
                    {
                        Textbox_Puzzle_27.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 26]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_28.Text == "" || Convert.ToInt32(Textbox_Puzzle_28.Text) != hardPuzzlesSolution[activePuzzleNum, 27])
                    {
                        Textbox_Puzzle_28.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 27]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_29.Text == "" || Convert.ToInt32(Textbox_Puzzle_29.Text) != hardPuzzlesSolution[activePuzzleNum, 28])
                    {
                        Textbox_Puzzle_29.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 28]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_30.Text == "" || Convert.ToInt32(Textbox_Puzzle_30.Text) != hardPuzzlesSolution[activePuzzleNum, 29])
                    {
                        Textbox_Puzzle_30.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 29]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_31.Text == "" || Convert.ToInt32(Textbox_Puzzle_31.Text) != hardPuzzlesSolution[activePuzzleNum, 30])
                    {
                        Textbox_Puzzle_31.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 30]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_32.Text == "" || Convert.ToInt32(Textbox_Puzzle_32.Text) != hardPuzzlesSolution[activePuzzleNum, 31])
                    {
                        Textbox_Puzzle_32.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 31]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_33.Text == "" || Convert.ToInt32(Textbox_Puzzle_33.Text) != hardPuzzlesSolution[activePuzzleNum, 32])
                    {
                        Textbox_Puzzle_33.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 32]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_34.Text == "" || Convert.ToInt32(Textbox_Puzzle_34.Text) != hardPuzzlesSolution[activePuzzleNum, 33])
                    {
                        Textbox_Puzzle_34.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 33]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_35.Text == "" || Convert.ToInt32(Textbox_Puzzle_35.Text) != hardPuzzlesSolution[activePuzzleNum, 34])
                    {
                        Textbox_Puzzle_35.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 34]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_36.Text == "" || Convert.ToInt32(Textbox_Puzzle_36.Text) != hardPuzzlesSolution[activePuzzleNum, 35])
                    {
                        Textbox_Puzzle_36.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 35]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_37.Text == "" || Convert.ToInt32(Textbox_Puzzle_37.Text) != hardPuzzlesSolution[activePuzzleNum, 36])
                    {
                        Textbox_Puzzle_37.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 36]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_38.Text == "" || Convert.ToInt32(Textbox_Puzzle_38.Text) != hardPuzzlesSolution[activePuzzleNum, 37])
                    {
                        Textbox_Puzzle_38.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 37]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_39.Text == "" || Convert.ToInt32(Textbox_Puzzle_39.Text) != hardPuzzlesSolution[activePuzzleNum, 38])
                    {
                        Textbox_Puzzle_39.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 38]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_40.Text == "" || Convert.ToInt32(Textbox_Puzzle_40.Text) != hardPuzzlesSolution[activePuzzleNum, 39])
                    {
                        Textbox_Puzzle_40.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 39]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_41.Text == "" || Convert.ToInt32(Textbox_Puzzle_41.Text) != hardPuzzlesSolution[activePuzzleNum, 40])
                    {
                        Textbox_Puzzle_41.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 40]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_42.Text == "" || Convert.ToInt32(Textbox_Puzzle_42.Text) != hardPuzzlesSolution[activePuzzleNum, 41])
                    {
                        Textbox_Puzzle_42.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 41]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_43.Text == "" || Convert.ToInt32(Textbox_Puzzle_43.Text) != hardPuzzlesSolution[activePuzzleNum, 42])
                    {
                        Textbox_Puzzle_43.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 42]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_44.Text == "" || Convert.ToInt32(Textbox_Puzzle_44.Text) != hardPuzzlesSolution[activePuzzleNum, 43])
                    {
                        Textbox_Puzzle_44.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 43]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_45.Text == "" || Convert.ToInt32(Textbox_Puzzle_45.Text) != hardPuzzlesSolution[activePuzzleNum, 44])
                    {
                        Textbox_Puzzle_45.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 44]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_46.Text == "" || Convert.ToInt32(Textbox_Puzzle_46.Text) != hardPuzzlesSolution[activePuzzleNum, 45])
                    {
                        Textbox_Puzzle_46.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 45]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_47.Text == "" || Convert.ToInt32(Textbox_Puzzle_47.Text) != hardPuzzlesSolution[activePuzzleNum, 46])
                    {
                        Textbox_Puzzle_47.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 46]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_48.Text == "" || Convert.ToInt32(Textbox_Puzzle_48.Text) != hardPuzzlesSolution[activePuzzleNum, 47])
                    {
                        Textbox_Puzzle_48.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 47]);
                        flag = true;
                        return;
                    }
                    if (Textbox_Puzzle_49.Text == "" || Convert.ToInt32(Textbox_Puzzle_49.Text) != hardPuzzlesSolution[activePuzzleNum, 48])
                    {
                        Textbox_Puzzle_49.Text = Convert.ToString(hardPuzzlesSolution[activePuzzleNum, 48]);
                        flag = true;
                        return;
                    }

                    break;



            }

        }

        private void Textbox_Focus(object sender, EventArgs e)
        {
            Select(false, false);
        }


    }
}
