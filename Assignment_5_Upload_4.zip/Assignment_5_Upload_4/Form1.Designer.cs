﻿namespace Assignment_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Textbox_Puzzle_1 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_2 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_3 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_4 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_5 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_6 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_7 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_36 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_29 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_22 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_43 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_14 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_13 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_12 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_11 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_10 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_9 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_8 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_21 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_20 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_19 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_18 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_17 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_16 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_15 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_42 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_41 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_40 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_39 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_38 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_37 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_35 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_34 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_33 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_32 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_31 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_30 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_28 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_27 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_26 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_25 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_24 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_23 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_49 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_48 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_47 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_46 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_45 = new System.Windows.Forms.TextBox();
            this.Textbox_Puzzle_44 = new System.Windows.Forms.TextBox();
            this.Button_Create_Puzzle = new System.Windows.Forms.Button();
            this.ComboBox_Difficulty = new System.Windows.Forms.ComboBox();
            this.Label_Puzzle_R1 = new System.Windows.Forms.Label();
            this.Label_Puzzle_R2 = new System.Windows.Forms.Label();
            this.Label_Puzzle_R3 = new System.Windows.Forms.Label();
            this.Label_Puzzle_R4 = new System.Windows.Forms.Label();
            this.Label_Puzzle_R5 = new System.Windows.Forms.Label();
            this.Label_Puzzle_R6 = new System.Windows.Forms.Label();
            this.Label_Puzzle_R7 = new System.Windows.Forms.Label();
            this.Label_Puzzle_D2 = new System.Windows.Forms.Label();
            this.Label_Puzzle_C1 = new System.Windows.Forms.Label();
            this.Label_Puzzle_C2 = new System.Windows.Forms.Label();
            this.Label_Puzzle_C3 = new System.Windows.Forms.Label();
            this.Label_Puzzle_C4 = new System.Windows.Forms.Label();
            this.Label_Puzzle_C5 = new System.Windows.Forms.Label();
            this.Label_Puzzle_C6 = new System.Windows.Forms.Label();
            this.Label_Puzzle_C7 = new System.Windows.Forms.Label();
            this.Label_Puzzle_D1 = new System.Windows.Forms.Label();
            this.Label_Timer = new System.Windows.Forms.Label();
            this.Button_Pause = new System.Windows.Forms.Button();
            this.Label_Puzzle_Sum_C7 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_C6 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_C5 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_C4 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_C3 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_C2 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_C1 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_D2 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_D1 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_R7 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_R6 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_R5 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_R4 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_R3 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_R2 = new System.Windows.Forms.Label();
            this.Label_Puzzle_Sum_R1 = new System.Windows.Forms.Label();
            this.Label_Title = new System.Windows.Forms.Label();
            this.Label_Fastest = new System.Windows.Forms.Label();
            this.Label_Average = new System.Windows.Forms.Label();
            this.Label_Difficulty = new System.Windows.Forms.Label();
            this.Button_Cheat = new System.Windows.Forms.Button();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.Label_Paused = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Textbox_Puzzle_1
            // 
            this.Textbox_Puzzle_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_1.Location = new System.Drawing.Point(20, 167);
            this.Textbox_Puzzle_1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_1.MaxLength = 1;
            this.Textbox_Puzzle_1.Name = "Textbox_Puzzle_1";
            this.Textbox_Puzzle_1.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_1.TabIndex = 0;
            this.Textbox_Puzzle_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_1.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_1.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_2
            // 
            this.Textbox_Puzzle_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_2.Location = new System.Drawing.Point(91, 167);
            this.Textbox_Puzzle_2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_2.MaxLength = 1;
            this.Textbox_Puzzle_2.Name = "Textbox_Puzzle_2";
            this.Textbox_Puzzle_2.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_2.TabIndex = 3;
            this.Textbox_Puzzle_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_2.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_2.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_3
            // 
            this.Textbox_Puzzle_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_3.Location = new System.Drawing.Point(161, 167);
            this.Textbox_Puzzle_3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_3.MaxLength = 1;
            this.Textbox_Puzzle_3.Name = "Textbox_Puzzle_3";
            this.Textbox_Puzzle_3.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_3.TabIndex = 4;
            this.Textbox_Puzzle_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_3.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_3.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_4
            // 
            this.Textbox_Puzzle_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_4.Location = new System.Drawing.Point(232, 167);
            this.Textbox_Puzzle_4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_4.MaxLength = 1;
            this.Textbox_Puzzle_4.Name = "Textbox_Puzzle_4";
            this.Textbox_Puzzle_4.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_4.TabIndex = 5;
            this.Textbox_Puzzle_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_4.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_4.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_5
            // 
            this.Textbox_Puzzle_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_5.Location = new System.Drawing.Point(303, 167);
            this.Textbox_Puzzle_5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_5.MaxLength = 1;
            this.Textbox_Puzzle_5.Name = "Textbox_Puzzle_5";
            this.Textbox_Puzzle_5.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_5.TabIndex = 6;
            this.Textbox_Puzzle_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_5.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_5.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_6
            // 
            this.Textbox_Puzzle_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_6.Location = new System.Drawing.Point(373, 167);
            this.Textbox_Puzzle_6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_6.MaxLength = 1;
            this.Textbox_Puzzle_6.Name = "Textbox_Puzzle_6";
            this.Textbox_Puzzle_6.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_6.TabIndex = 7;
            this.Textbox_Puzzle_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_6.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_6.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_7
            // 
            this.Textbox_Puzzle_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_7.Location = new System.Drawing.Point(444, 167);
            this.Textbox_Puzzle_7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_7.MaxLength = 1;
            this.Textbox_Puzzle_7.Name = "Textbox_Puzzle_7";
            this.Textbox_Puzzle_7.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_7.TabIndex = 8;
            this.Textbox_Puzzle_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_7.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_7.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_36
            // 
            this.Textbox_Puzzle_36.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_36.Location = new System.Drawing.Point(20, 506);
            this.Textbox_Puzzle_36.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_36.MaxLength = 1;
            this.Textbox_Puzzle_36.Name = "Textbox_Puzzle_36";
            this.Textbox_Puzzle_36.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_36.TabIndex = 19;
            this.Textbox_Puzzle_36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_36.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_36.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_36.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_29
            // 
            this.Textbox_Puzzle_29.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_29.Location = new System.Drawing.Point(20, 438);
            this.Textbox_Puzzle_29.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_29.MaxLength = 1;
            this.Textbox_Puzzle_29.Name = "Textbox_Puzzle_29";
            this.Textbox_Puzzle_29.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_29.TabIndex = 18;
            this.Textbox_Puzzle_29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_29.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_29.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_29.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_22
            // 
            this.Textbox_Puzzle_22.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_22.Location = new System.Drawing.Point(20, 370);
            this.Textbox_Puzzle_22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_22.MaxLength = 1;
            this.Textbox_Puzzle_22.Name = "Textbox_Puzzle_22";
            this.Textbox_Puzzle_22.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_22.TabIndex = 17;
            this.Textbox_Puzzle_22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_22.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_22.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_22.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_43
            // 
            this.Textbox_Puzzle_43.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_43.Location = new System.Drawing.Point(20, 574);
            this.Textbox_Puzzle_43.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_43.MaxLength = 1;
            this.Textbox_Puzzle_43.Name = "Textbox_Puzzle_43";
            this.Textbox_Puzzle_43.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_43.TabIndex = 20;
            this.Textbox_Puzzle_43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_43.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_43.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_43.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_14
            // 
            this.Textbox_Puzzle_14.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_14.Location = new System.Drawing.Point(444, 235);
            this.Textbox_Puzzle_14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_14.MaxLength = 1;
            this.Textbox_Puzzle_14.Name = "Textbox_Puzzle_14";
            this.Textbox_Puzzle_14.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_14.TabIndex = 27;
            this.Textbox_Puzzle_14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_14.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_14.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_14.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_13
            // 
            this.Textbox_Puzzle_13.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_13.Location = new System.Drawing.Point(373, 235);
            this.Textbox_Puzzle_13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_13.MaxLength = 1;
            this.Textbox_Puzzle_13.Name = "Textbox_Puzzle_13";
            this.Textbox_Puzzle_13.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_13.TabIndex = 26;
            this.Textbox_Puzzle_13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_13.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_13.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_13.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_12
            // 
            this.Textbox_Puzzle_12.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_12.Location = new System.Drawing.Point(303, 235);
            this.Textbox_Puzzle_12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_12.MaxLength = 1;
            this.Textbox_Puzzle_12.Name = "Textbox_Puzzle_12";
            this.Textbox_Puzzle_12.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_12.TabIndex = 25;
            this.Textbox_Puzzle_12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_12.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_12.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_12.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_11
            // 
            this.Textbox_Puzzle_11.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_11.Location = new System.Drawing.Point(232, 235);
            this.Textbox_Puzzle_11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_11.MaxLength = 1;
            this.Textbox_Puzzle_11.Name = "Textbox_Puzzle_11";
            this.Textbox_Puzzle_11.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_11.TabIndex = 24;
            this.Textbox_Puzzle_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_11.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_11.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_11.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_10
            // 
            this.Textbox_Puzzle_10.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_10.Location = new System.Drawing.Point(161, 235);
            this.Textbox_Puzzle_10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_10.MaxLength = 1;
            this.Textbox_Puzzle_10.Name = "Textbox_Puzzle_10";
            this.Textbox_Puzzle_10.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_10.TabIndex = 23;
            this.Textbox_Puzzle_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_10.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_10.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_9
            // 
            this.Textbox_Puzzle_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_9.Location = new System.Drawing.Point(91, 235);
            this.Textbox_Puzzle_9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_9.MaxLength = 1;
            this.Textbox_Puzzle_9.Name = "Textbox_Puzzle_9";
            this.Textbox_Puzzle_9.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_9.TabIndex = 22;
            this.Textbox_Puzzle_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_9.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_9.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_8
            // 
            this.Textbox_Puzzle_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_8.Location = new System.Drawing.Point(20, 235);
            this.Textbox_Puzzle_8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_8.MaxLength = 1;
            this.Textbox_Puzzle_8.Name = "Textbox_Puzzle_8";
            this.Textbox_Puzzle_8.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_8.TabIndex = 21;
            this.Textbox_Puzzle_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_8.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_8.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_21
            // 
            this.Textbox_Puzzle_21.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_21.Location = new System.Drawing.Point(444, 303);
            this.Textbox_Puzzle_21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_21.MaxLength = 1;
            this.Textbox_Puzzle_21.Name = "Textbox_Puzzle_21";
            this.Textbox_Puzzle_21.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_21.TabIndex = 34;
            this.Textbox_Puzzle_21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_21.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_21.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_21.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_20
            // 
            this.Textbox_Puzzle_20.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_20.Location = new System.Drawing.Point(373, 303);
            this.Textbox_Puzzle_20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_20.MaxLength = 1;
            this.Textbox_Puzzle_20.Name = "Textbox_Puzzle_20";
            this.Textbox_Puzzle_20.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_20.TabIndex = 33;
            this.Textbox_Puzzle_20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_20.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_20.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_20.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_19
            // 
            this.Textbox_Puzzle_19.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_19.Location = new System.Drawing.Point(303, 303);
            this.Textbox_Puzzle_19.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_19.MaxLength = 1;
            this.Textbox_Puzzle_19.Name = "Textbox_Puzzle_19";
            this.Textbox_Puzzle_19.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_19.TabIndex = 32;
            this.Textbox_Puzzle_19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_19.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_19.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_19.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_18
            // 
            this.Textbox_Puzzle_18.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_18.Location = new System.Drawing.Point(232, 303);
            this.Textbox_Puzzle_18.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_18.MaxLength = 1;
            this.Textbox_Puzzle_18.Name = "Textbox_Puzzle_18";
            this.Textbox_Puzzle_18.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_18.TabIndex = 31;
            this.Textbox_Puzzle_18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_18.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_18.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_18.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_17
            // 
            this.Textbox_Puzzle_17.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_17.Location = new System.Drawing.Point(161, 303);
            this.Textbox_Puzzle_17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_17.MaxLength = 1;
            this.Textbox_Puzzle_17.Name = "Textbox_Puzzle_17";
            this.Textbox_Puzzle_17.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_17.TabIndex = 30;
            this.Textbox_Puzzle_17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_17.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_17.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_17.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_16
            // 
            this.Textbox_Puzzle_16.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_16.Location = new System.Drawing.Point(91, 303);
            this.Textbox_Puzzle_16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_16.MaxLength = 1;
            this.Textbox_Puzzle_16.Name = "Textbox_Puzzle_16";
            this.Textbox_Puzzle_16.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_16.TabIndex = 29;
            this.Textbox_Puzzle_16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_16.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_16.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_16.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_15
            // 
            this.Textbox_Puzzle_15.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_15.Location = new System.Drawing.Point(20, 303);
            this.Textbox_Puzzle_15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_15.MaxLength = 1;
            this.Textbox_Puzzle_15.Name = "Textbox_Puzzle_15";
            this.Textbox_Puzzle_15.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_15.TabIndex = 28;
            this.Textbox_Puzzle_15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_15.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_15.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_15.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_42
            // 
            this.Textbox_Puzzle_42.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_42.Location = new System.Drawing.Point(444, 506);
            this.Textbox_Puzzle_42.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_42.MaxLength = 1;
            this.Textbox_Puzzle_42.Name = "Textbox_Puzzle_42";
            this.Textbox_Puzzle_42.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_42.TabIndex = 52;
            this.Textbox_Puzzle_42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_42.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_42.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_42.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_41
            // 
            this.Textbox_Puzzle_41.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_41.Location = new System.Drawing.Point(373, 506);
            this.Textbox_Puzzle_41.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_41.MaxLength = 1;
            this.Textbox_Puzzle_41.Name = "Textbox_Puzzle_41";
            this.Textbox_Puzzle_41.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_41.TabIndex = 51;
            this.Textbox_Puzzle_41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_41.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_41.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_41.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_40
            // 
            this.Textbox_Puzzle_40.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_40.Location = new System.Drawing.Point(303, 506);
            this.Textbox_Puzzle_40.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_40.MaxLength = 1;
            this.Textbox_Puzzle_40.Name = "Textbox_Puzzle_40";
            this.Textbox_Puzzle_40.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_40.TabIndex = 50;
            this.Textbox_Puzzle_40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_40.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_40.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_40.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_39
            // 
            this.Textbox_Puzzle_39.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_39.Location = new System.Drawing.Point(232, 506);
            this.Textbox_Puzzle_39.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_39.MaxLength = 1;
            this.Textbox_Puzzle_39.Name = "Textbox_Puzzle_39";
            this.Textbox_Puzzle_39.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_39.TabIndex = 49;
            this.Textbox_Puzzle_39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_39.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_39.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_39.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_38
            // 
            this.Textbox_Puzzle_38.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_38.Location = new System.Drawing.Point(161, 506);
            this.Textbox_Puzzle_38.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_38.MaxLength = 1;
            this.Textbox_Puzzle_38.Name = "Textbox_Puzzle_38";
            this.Textbox_Puzzle_38.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_38.TabIndex = 48;
            this.Textbox_Puzzle_38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_38.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_38.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_38.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_37
            // 
            this.Textbox_Puzzle_37.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_37.Location = new System.Drawing.Point(91, 506);
            this.Textbox_Puzzle_37.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_37.MaxLength = 1;
            this.Textbox_Puzzle_37.Name = "Textbox_Puzzle_37";
            this.Textbox_Puzzle_37.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_37.TabIndex = 47;
            this.Textbox_Puzzle_37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_37.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_37.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_37.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_35
            // 
            this.Textbox_Puzzle_35.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_35.Location = new System.Drawing.Point(444, 438);
            this.Textbox_Puzzle_35.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_35.MaxLength = 1;
            this.Textbox_Puzzle_35.Name = "Textbox_Puzzle_35";
            this.Textbox_Puzzle_35.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_35.TabIndex = 46;
            this.Textbox_Puzzle_35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_35.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_35.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_35.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_34
            // 
            this.Textbox_Puzzle_34.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_34.Location = new System.Drawing.Point(373, 438);
            this.Textbox_Puzzle_34.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_34.MaxLength = 1;
            this.Textbox_Puzzle_34.Name = "Textbox_Puzzle_34";
            this.Textbox_Puzzle_34.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_34.TabIndex = 45;
            this.Textbox_Puzzle_34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_34.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_34.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_34.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_33
            // 
            this.Textbox_Puzzle_33.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_33.Location = new System.Drawing.Point(303, 438);
            this.Textbox_Puzzle_33.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_33.MaxLength = 1;
            this.Textbox_Puzzle_33.Name = "Textbox_Puzzle_33";
            this.Textbox_Puzzle_33.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_33.TabIndex = 44;
            this.Textbox_Puzzle_33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_33.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_33.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_33.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_32
            // 
            this.Textbox_Puzzle_32.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_32.Location = new System.Drawing.Point(232, 438);
            this.Textbox_Puzzle_32.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_32.MaxLength = 1;
            this.Textbox_Puzzle_32.Name = "Textbox_Puzzle_32";
            this.Textbox_Puzzle_32.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_32.TabIndex = 43;
            this.Textbox_Puzzle_32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_32.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_32.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_32.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_31
            // 
            this.Textbox_Puzzle_31.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_31.Location = new System.Drawing.Point(161, 438);
            this.Textbox_Puzzle_31.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_31.MaxLength = 1;
            this.Textbox_Puzzle_31.Name = "Textbox_Puzzle_31";
            this.Textbox_Puzzle_31.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_31.TabIndex = 42;
            this.Textbox_Puzzle_31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_31.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_31.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_31.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_30
            // 
            this.Textbox_Puzzle_30.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_30.Location = new System.Drawing.Point(91, 438);
            this.Textbox_Puzzle_30.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_30.MaxLength = 1;
            this.Textbox_Puzzle_30.Name = "Textbox_Puzzle_30";
            this.Textbox_Puzzle_30.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_30.TabIndex = 41;
            this.Textbox_Puzzle_30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_30.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_30.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_30.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_28
            // 
            this.Textbox_Puzzle_28.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_28.Location = new System.Drawing.Point(444, 370);
            this.Textbox_Puzzle_28.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_28.MaxLength = 1;
            this.Textbox_Puzzle_28.Name = "Textbox_Puzzle_28";
            this.Textbox_Puzzle_28.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_28.TabIndex = 40;
            this.Textbox_Puzzle_28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_28.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_28.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_28.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_27
            // 
            this.Textbox_Puzzle_27.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_27.Location = new System.Drawing.Point(373, 370);
            this.Textbox_Puzzle_27.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_27.MaxLength = 1;
            this.Textbox_Puzzle_27.Name = "Textbox_Puzzle_27";
            this.Textbox_Puzzle_27.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_27.TabIndex = 39;
            this.Textbox_Puzzle_27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_27.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_27.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_27.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_26
            // 
            this.Textbox_Puzzle_26.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_26.Location = new System.Drawing.Point(303, 370);
            this.Textbox_Puzzle_26.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_26.MaxLength = 1;
            this.Textbox_Puzzle_26.Name = "Textbox_Puzzle_26";
            this.Textbox_Puzzle_26.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_26.TabIndex = 38;
            this.Textbox_Puzzle_26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_26.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_26.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_26.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_25
            // 
            this.Textbox_Puzzle_25.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_25.Location = new System.Drawing.Point(232, 370);
            this.Textbox_Puzzle_25.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_25.MaxLength = 1;
            this.Textbox_Puzzle_25.Name = "Textbox_Puzzle_25";
            this.Textbox_Puzzle_25.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_25.TabIndex = 37;
            this.Textbox_Puzzle_25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_25.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_25.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_25.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_24
            // 
            this.Textbox_Puzzle_24.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_24.Location = new System.Drawing.Point(161, 370);
            this.Textbox_Puzzle_24.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_24.MaxLength = 1;
            this.Textbox_Puzzle_24.Name = "Textbox_Puzzle_24";
            this.Textbox_Puzzle_24.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_24.TabIndex = 36;
            this.Textbox_Puzzle_24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_24.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_24.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_24.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_23
            // 
            this.Textbox_Puzzle_23.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_23.Location = new System.Drawing.Point(91, 370);
            this.Textbox_Puzzle_23.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_23.MaxLength = 1;
            this.Textbox_Puzzle_23.Name = "Textbox_Puzzle_23";
            this.Textbox_Puzzle_23.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_23.TabIndex = 35;
            this.Textbox_Puzzle_23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_23.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_23.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_23.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_49
            // 
            this.Textbox_Puzzle_49.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_49.Location = new System.Drawing.Point(444, 574);
            this.Textbox_Puzzle_49.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_49.MaxLength = 1;
            this.Textbox_Puzzle_49.Name = "Textbox_Puzzle_49";
            this.Textbox_Puzzle_49.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_49.TabIndex = 58;
            this.Textbox_Puzzle_49.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_49.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_49.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_49.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_48
            // 
            this.Textbox_Puzzle_48.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_48.Location = new System.Drawing.Point(373, 574);
            this.Textbox_Puzzle_48.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_48.MaxLength = 1;
            this.Textbox_Puzzle_48.Name = "Textbox_Puzzle_48";
            this.Textbox_Puzzle_48.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_48.TabIndex = 57;
            this.Textbox_Puzzle_48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_48.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_48.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_48.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_47
            // 
            this.Textbox_Puzzle_47.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_47.Location = new System.Drawing.Point(303, 574);
            this.Textbox_Puzzle_47.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_47.MaxLength = 1;
            this.Textbox_Puzzle_47.Name = "Textbox_Puzzle_47";
            this.Textbox_Puzzle_47.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_47.TabIndex = 56;
            this.Textbox_Puzzle_47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_47.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_47.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_47.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_46
            // 
            this.Textbox_Puzzle_46.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_46.Location = new System.Drawing.Point(232, 574);
            this.Textbox_Puzzle_46.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_46.MaxLength = 1;
            this.Textbox_Puzzle_46.Name = "Textbox_Puzzle_46";
            this.Textbox_Puzzle_46.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_46.TabIndex = 55;
            this.Textbox_Puzzle_46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_46.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_46.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_46.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_45
            // 
            this.Textbox_Puzzle_45.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_45.Location = new System.Drawing.Point(161, 574);
            this.Textbox_Puzzle_45.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_45.MaxLength = 1;
            this.Textbox_Puzzle_45.Name = "Textbox_Puzzle_45";
            this.Textbox_Puzzle_45.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_45.TabIndex = 54;
            this.Textbox_Puzzle_45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_45.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_45.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_45.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Textbox_Puzzle_44
            // 
            this.Textbox_Puzzle_44.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Puzzle_44.Location = new System.Drawing.Point(91, 574);
            this.Textbox_Puzzle_44.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_Puzzle_44.MaxLength = 1;
            this.Textbox_Puzzle_44.Name = "Textbox_Puzzle_44";
            this.Textbox_Puzzle_44.Size = new System.Drawing.Size(61, 60);
            this.Textbox_Puzzle_44.TabIndex = 53;
            this.Textbox_Puzzle_44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Textbox_Puzzle_44.TextChanged += new System.EventHandler(this.Textbox_Puzzle_TextChanged);
            this.Textbox_Puzzle_44.Enter += new System.EventHandler(this.Textbox_Focus);
            this.Textbox_Puzzle_44.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Puzzle_KeyPress);
            // 
            // Button_Create_Puzzle
            // 
            this.Button_Create_Puzzle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Create_Puzzle.Location = new System.Drawing.Point(976, 108);
            this.Button_Create_Puzzle.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Create_Puzzle.Name = "Button_Create_Puzzle";
            this.Button_Create_Puzzle.Size = new System.Drawing.Size(139, 36);
            this.Button_Create_Puzzle.TabIndex = 59;
            this.Button_Create_Puzzle.Text = "New Puzzle";
            this.Button_Create_Puzzle.UseVisualStyleBackColor = true;
            this.Button_Create_Puzzle.Click += new System.EventHandler(this.Button_Create_Puzzle_Click);
            // 
            // ComboBox_Difficulty
            // 
            this.ComboBox_Difficulty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBox_Difficulty.FormattingEnabled = true;
            this.ComboBox_Difficulty.Items.AddRange(new object[] {
            "Easy",
            "Medium",
            "Hard"});
            this.ComboBox_Difficulty.Location = new System.Drawing.Point(828, 110);
            this.ComboBox_Difficulty.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ComboBox_Difficulty.Name = "ComboBox_Difficulty";
            this.ComboBox_Difficulty.Size = new System.Drawing.Size(132, 33);
            this.ComboBox_Difficulty.TabIndex = 60;
            // 
            // Label_Puzzle_R1
            // 
            this.Label_Puzzle_R1.AutoSize = true;
            this.Label_Puzzle_R1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_R1.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_R1.Location = new System.Drawing.Point(515, 178);
            this.Label_Puzzle_R1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_R1.Name = "Label_Puzzle_R1";
            this.Label_Puzzle_R1.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_R1.TabIndex = 62;
            this.Label_Puzzle_R1.Text = "00";
            // 
            // Label_Puzzle_R2
            // 
            this.Label_Puzzle_R2.AutoSize = true;
            this.Label_Puzzle_R2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_R2.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_R2.Location = new System.Drawing.Point(515, 246);
            this.Label_Puzzle_R2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_R2.Name = "Label_Puzzle_R2";
            this.Label_Puzzle_R2.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_R2.TabIndex = 63;
            this.Label_Puzzle_R2.Text = "00";
            // 
            // Label_Puzzle_R3
            // 
            this.Label_Puzzle_R3.AutoSize = true;
            this.Label_Puzzle_R3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_R3.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_R3.Location = new System.Drawing.Point(515, 314);
            this.Label_Puzzle_R3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_R3.Name = "Label_Puzzle_R3";
            this.Label_Puzzle_R3.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_R3.TabIndex = 64;
            this.Label_Puzzle_R3.Text = "00";
            // 
            // Label_Puzzle_R4
            // 
            this.Label_Puzzle_R4.AutoSize = true;
            this.Label_Puzzle_R4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_R4.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_R4.Location = new System.Drawing.Point(515, 382);
            this.Label_Puzzle_R4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_R4.Name = "Label_Puzzle_R4";
            this.Label_Puzzle_R4.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_R4.TabIndex = 65;
            this.Label_Puzzle_R4.Text = "00";
            // 
            // Label_Puzzle_R5
            // 
            this.Label_Puzzle_R5.AutoSize = true;
            this.Label_Puzzle_R5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_R5.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_R5.Location = new System.Drawing.Point(515, 449);
            this.Label_Puzzle_R5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_R5.Name = "Label_Puzzle_R5";
            this.Label_Puzzle_R5.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_R5.TabIndex = 66;
            this.Label_Puzzle_R5.Text = "00";
            // 
            // Label_Puzzle_R6
            // 
            this.Label_Puzzle_R6.AutoSize = true;
            this.Label_Puzzle_R6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_R6.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_R6.Location = new System.Drawing.Point(515, 517);
            this.Label_Puzzle_R6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_R6.Name = "Label_Puzzle_R6";
            this.Label_Puzzle_R6.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_R6.TabIndex = 67;
            this.Label_Puzzle_R6.Text = "00";
            // 
            // Label_Puzzle_R7
            // 
            this.Label_Puzzle_R7.AutoSize = true;
            this.Label_Puzzle_R7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_R7.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_R7.Location = new System.Drawing.Point(515, 585);
            this.Label_Puzzle_R7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_R7.Name = "Label_Puzzle_R7";
            this.Label_Puzzle_R7.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_R7.TabIndex = 68;
            this.Label_Puzzle_R7.Text = "00";
            // 
            // Label_Puzzle_D2
            // 
            this.Label_Puzzle_D2.AutoSize = true;
            this.Label_Puzzle_D2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_D2.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_D2.Location = new System.Drawing.Point(515, 644);
            this.Label_Puzzle_D2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_D2.Name = "Label_Puzzle_D2";
            this.Label_Puzzle_D2.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_D2.TabIndex = 70;
            this.Label_Puzzle_D2.Text = "00";
            // 
            // Label_Puzzle_C1
            // 
            this.Label_Puzzle_C1.AutoSize = true;
            this.Label_Puzzle_C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_C1.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_C1.Location = new System.Drawing.Point(20, 644);
            this.Label_Puzzle_C1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_C1.Name = "Label_Puzzle_C1";
            this.Label_Puzzle_C1.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_C1.TabIndex = 71;
            this.Label_Puzzle_C1.Text = "00";
            // 
            // Label_Puzzle_C2
            // 
            this.Label_Puzzle_C2.AutoSize = true;
            this.Label_Puzzle_C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_C2.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_C2.Location = new System.Drawing.Point(89, 644);
            this.Label_Puzzle_C2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_C2.Name = "Label_Puzzle_C2";
            this.Label_Puzzle_C2.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_C2.TabIndex = 72;
            this.Label_Puzzle_C2.Text = "00";
            // 
            // Label_Puzzle_C3
            // 
            this.Label_Puzzle_C3.AutoSize = true;
            this.Label_Puzzle_C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_C3.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_C3.Location = new System.Drawing.Point(160, 644);
            this.Label_Puzzle_C3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_C3.Name = "Label_Puzzle_C3";
            this.Label_Puzzle_C3.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_C3.TabIndex = 73;
            this.Label_Puzzle_C3.Text = "00";
            // 
            // Label_Puzzle_C4
            // 
            this.Label_Puzzle_C4.AutoSize = true;
            this.Label_Puzzle_C4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_C4.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_C4.Location = new System.Drawing.Point(231, 644);
            this.Label_Puzzle_C4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_C4.Name = "Label_Puzzle_C4";
            this.Label_Puzzle_C4.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_C4.TabIndex = 74;
            this.Label_Puzzle_C4.Text = "00";
            // 
            // Label_Puzzle_C5
            // 
            this.Label_Puzzle_C5.AutoSize = true;
            this.Label_Puzzle_C5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_C5.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_C5.Location = new System.Drawing.Point(301, 644);
            this.Label_Puzzle_C5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_C5.Name = "Label_Puzzle_C5";
            this.Label_Puzzle_C5.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_C5.TabIndex = 75;
            this.Label_Puzzle_C5.Text = "00";
            // 
            // Label_Puzzle_C6
            // 
            this.Label_Puzzle_C6.AutoSize = true;
            this.Label_Puzzle_C6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_C6.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_C6.Location = new System.Drawing.Point(375, 644);
            this.Label_Puzzle_C6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_C6.Name = "Label_Puzzle_C6";
            this.Label_Puzzle_C6.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_C6.TabIndex = 76;
            this.Label_Puzzle_C6.Text = "00";
            // 
            // Label_Puzzle_C7
            // 
            this.Label_Puzzle_C7.AutoSize = true;
            this.Label_Puzzle_C7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_C7.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_C7.Location = new System.Drawing.Point(445, 644);
            this.Label_Puzzle_C7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_C7.Name = "Label_Puzzle_C7";
            this.Label_Puzzle_C7.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_C7.TabIndex = 77;
            this.Label_Puzzle_C7.Text = "00";
            // 
            // Label_Puzzle_D1
            // 
            this.Label_Puzzle_D1.AutoSize = true;
            this.Label_Puzzle_D1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_D1.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_D1.Location = new System.Drawing.Point(515, 134);
            this.Label_Puzzle_D1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_D1.Name = "Label_Puzzle_D1";
            this.Label_Puzzle_D1.Size = new System.Drawing.Size(49, 36);
            this.Label_Puzzle_D1.TabIndex = 79;
            this.Label_Puzzle_D1.Text = "00";
            // 
            // Label_Timer
            // 
            this.Label_Timer.AutoSize = true;
            this.Label_Timer.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Label_Timer.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Timer.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Timer.Location = new System.Drawing.Point(927, 30);
            this.Label_Timer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Timer.Name = "Label_Timer";
            this.Label_Timer.Size = new System.Drawing.Size(179, 52);
            this.Label_Timer.TabIndex = 81;
            this.Label_Timer.Text = "999:999";
            // 
            // Button_Pause
            // 
            this.Button_Pause.Enabled = false;
            this.Button_Pause.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Pause.Location = new System.Drawing.Point(796, 28);
            this.Button_Pause.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Pause.Name = "Button_Pause";
            this.Button_Pause.Size = new System.Drawing.Size(123, 47);
            this.Button_Pause.TabIndex = 82;
            this.Button_Pause.Text = "Pause";
            this.Button_Pause.UseVisualStyleBackColor = true;
            this.Button_Pause.Click += new System.EventHandler(this.Button_Pause_Click);
            // 
            // Label_Puzzle_Sum_C7
            // 
            this.Label_Puzzle_Sum_C7.AutoSize = true;
            this.Label_Puzzle_Sum_C7.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_C7.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_C7.Location = new System.Drawing.Point(443, 679);
            this.Label_Puzzle_Sum_C7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_C7.Name = "Label_Puzzle_Sum_C7";
            this.Label_Puzzle_Sum_C7.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_C7.TabIndex = 90;
            this.Label_Puzzle_Sum_C7.Text = "00";
            // 
            // Label_Puzzle_Sum_C6
            // 
            this.Label_Puzzle_Sum_C6.AutoSize = true;
            this.Label_Puzzle_Sum_C6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_C6.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_C6.Location = new System.Drawing.Point(372, 679);
            this.Label_Puzzle_Sum_C6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_C6.Name = "Label_Puzzle_Sum_C6";
            this.Label_Puzzle_Sum_C6.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_C6.TabIndex = 89;
            this.Label_Puzzle_Sum_C6.Text = "00";
            // 
            // Label_Puzzle_Sum_C5
            // 
            this.Label_Puzzle_Sum_C5.AutoSize = true;
            this.Label_Puzzle_Sum_C5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_C5.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_C5.Location = new System.Drawing.Point(301, 679);
            this.Label_Puzzle_Sum_C5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_C5.Name = "Label_Puzzle_Sum_C5";
            this.Label_Puzzle_Sum_C5.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_C5.TabIndex = 88;
            this.Label_Puzzle_Sum_C5.Text = "00";
            // 
            // Label_Puzzle_Sum_C4
            // 
            this.Label_Puzzle_Sum_C4.AutoSize = true;
            this.Label_Puzzle_Sum_C4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_C4.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_C4.Location = new System.Drawing.Point(231, 679);
            this.Label_Puzzle_Sum_C4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_C4.Name = "Label_Puzzle_Sum_C4";
            this.Label_Puzzle_Sum_C4.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_C4.TabIndex = 87;
            this.Label_Puzzle_Sum_C4.Text = "00";
            // 
            // Label_Puzzle_Sum_C3
            // 
            this.Label_Puzzle_Sum_C3.AutoSize = true;
            this.Label_Puzzle_Sum_C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_C3.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_C3.Location = new System.Drawing.Point(160, 679);
            this.Label_Puzzle_Sum_C3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_C3.Name = "Label_Puzzle_Sum_C3";
            this.Label_Puzzle_Sum_C3.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_C3.TabIndex = 86;
            this.Label_Puzzle_Sum_C3.Text = "00";
            // 
            // Label_Puzzle_Sum_C2
            // 
            this.Label_Puzzle_Sum_C2.AutoSize = true;
            this.Label_Puzzle_Sum_C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_C2.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_C2.Location = new System.Drawing.Point(89, 679);
            this.Label_Puzzle_Sum_C2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_C2.Name = "Label_Puzzle_Sum_C2";
            this.Label_Puzzle_Sum_C2.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_C2.TabIndex = 85;
            this.Label_Puzzle_Sum_C2.Text = "00";
            // 
            // Label_Puzzle_Sum_C1
            // 
            this.Label_Puzzle_Sum_C1.AutoSize = true;
            this.Label_Puzzle_Sum_C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_C1.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_C1.Location = new System.Drawing.Point(20, 679);
            this.Label_Puzzle_Sum_C1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_C1.Name = "Label_Puzzle_Sum_C1";
            this.Label_Puzzle_Sum_C1.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_C1.TabIndex = 84;
            this.Label_Puzzle_Sum_C1.Text = "00";
            // 
            // Label_Puzzle_Sum_D2
            // 
            this.Label_Puzzle_Sum_D2.AutoSize = true;
            this.Label_Puzzle_Sum_D2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_D2.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_D2.Location = new System.Drawing.Point(559, 662);
            this.Label_Puzzle_Sum_D2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_D2.Name = "Label_Puzzle_Sum_D2";
            this.Label_Puzzle_Sum_D2.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_D2.TabIndex = 83;
            this.Label_Puzzle_Sum_D2.Text = "00";
            // 
            // Label_Puzzle_Sum_D1
            // 
            this.Label_Puzzle_Sum_D1.AutoSize = true;
            this.Label_Puzzle_Sum_D1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_D1.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_D1.Location = new System.Drawing.Point(559, 108);
            this.Label_Puzzle_Sum_D1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_D1.Name = "Label_Puzzle_Sum_D1";
            this.Label_Puzzle_Sum_D1.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_D1.TabIndex = 98;
            this.Label_Puzzle_Sum_D1.Text = "00";
            // 
            // Label_Puzzle_Sum_R7
            // 
            this.Label_Puzzle_Sum_R7.AutoSize = true;
            this.Label_Puzzle_Sum_R7.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_R7.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_R7.Location = new System.Drawing.Point(559, 585);
            this.Label_Puzzle_Sum_R7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_R7.Name = "Label_Puzzle_Sum_R7";
            this.Label_Puzzle_Sum_R7.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_R7.TabIndex = 97;
            this.Label_Puzzle_Sum_R7.Text = "00";
            // 
            // Label_Puzzle_Sum_R6
            // 
            this.Label_Puzzle_Sum_R6.AutoSize = true;
            this.Label_Puzzle_Sum_R6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_R6.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_R6.Location = new System.Drawing.Point(559, 517);
            this.Label_Puzzle_Sum_R6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_R6.Name = "Label_Puzzle_Sum_R6";
            this.Label_Puzzle_Sum_R6.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_R6.TabIndex = 96;
            this.Label_Puzzle_Sum_R6.Text = "00";
            // 
            // Label_Puzzle_Sum_R5
            // 
            this.Label_Puzzle_Sum_R5.AutoSize = true;
            this.Label_Puzzle_Sum_R5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_R5.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_R5.Location = new System.Drawing.Point(559, 449);
            this.Label_Puzzle_Sum_R5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_R5.Name = "Label_Puzzle_Sum_R5";
            this.Label_Puzzle_Sum_R5.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_R5.TabIndex = 95;
            this.Label_Puzzle_Sum_R5.Text = "00";
            // 
            // Label_Puzzle_Sum_R4
            // 
            this.Label_Puzzle_Sum_R4.AutoSize = true;
            this.Label_Puzzle_Sum_R4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_R4.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_R4.Location = new System.Drawing.Point(559, 382);
            this.Label_Puzzle_Sum_R4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_R4.Name = "Label_Puzzle_Sum_R4";
            this.Label_Puzzle_Sum_R4.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_R4.TabIndex = 94;
            this.Label_Puzzle_Sum_R4.Text = "00";
            // 
            // Label_Puzzle_Sum_R3
            // 
            this.Label_Puzzle_Sum_R3.AutoSize = true;
            this.Label_Puzzle_Sum_R3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_R3.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_R3.Location = new System.Drawing.Point(559, 314);
            this.Label_Puzzle_Sum_R3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_R3.Name = "Label_Puzzle_Sum_R3";
            this.Label_Puzzle_Sum_R3.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_R3.TabIndex = 93;
            this.Label_Puzzle_Sum_R3.Text = "00";
            // 
            // Label_Puzzle_Sum_R2
            // 
            this.Label_Puzzle_Sum_R2.AutoSize = true;
            this.Label_Puzzle_Sum_R2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_R2.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_R2.Location = new System.Drawing.Point(559, 246);
            this.Label_Puzzle_Sum_R2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_R2.Name = "Label_Puzzle_Sum_R2";
            this.Label_Puzzle_Sum_R2.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_R2.TabIndex = 92;
            this.Label_Puzzle_Sum_R2.Text = "00";
            // 
            // Label_Puzzle_Sum_R1
            // 
            this.Label_Puzzle_Sum_R1.AutoSize = true;
            this.Label_Puzzle_Sum_R1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Puzzle_Sum_R1.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Puzzle_Sum_R1.Location = new System.Drawing.Point(559, 178);
            this.Label_Puzzle_Sum_R1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Puzzle_Sum_R1.Name = "Label_Puzzle_Sum_R1";
            this.Label_Puzzle_Sum_R1.Size = new System.Drawing.Size(64, 46);
            this.Label_Puzzle_Sum_R1.TabIndex = 91;
            this.Label_Puzzle_Sum_R1.Text = "00";
            // 
            // Label_Title
            // 
            this.Label_Title.AutoSize = true;
            this.Label_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Title.Location = new System.Drawing.Point(13, 6);
            this.Label_Title.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(477, 72);
            this.Label_Title.TabIndex = 99;
            this.Label_Title.Text = "Calculate the correct Sum for each \r\nColumn, Row, and Diagonal\r\n";
            this.Label_Title.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Label_Fastest
            // 
            this.Label_Fastest.AutoSize = true;
            this.Label_Fastest.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Fastest.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Fastest.Location = new System.Drawing.Point(681, 260);
            this.Label_Fastest.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Fastest.Name = "Label_Fastest";
            this.Label_Fastest.Size = new System.Drawing.Size(191, 36);
            this.Label_Fastest.TabIndex = 100;
            this.Label_Fastest.Text = "Fastest Time:";
            this.Label_Fastest.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Label_Average
            // 
            this.Label_Average.AutoSize = true;
            this.Label_Average.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Average.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Average.Location = new System.Drawing.Point(667, 311);
            this.Label_Average.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Average.Name = "Label_Average";
            this.Label_Average.Size = new System.Drawing.Size(206, 36);
            this.Label_Average.TabIndex = 101;
            this.Label_Average.Text = "Average Time:";
            this.Label_Average.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Label_Difficulty
            // 
            this.Label_Difficulty.AutoSize = true;
            this.Label_Difficulty.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Difficulty.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Difficulty.Location = new System.Drawing.Point(111, 110);
            this.Label_Difficulty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Difficulty.Name = "Label_Difficulty";
            this.Label_Difficulty.Size = new System.Drawing.Size(278, 54);
            this.Label_Difficulty.TabIndex = 102;
            this.Label_Difficulty.Text = "Hard Puzzle";
            this.Label_Difficulty.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Button_Cheat
            // 
            this.Button_Cheat.Enabled = false;
            this.Button_Cheat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Cheat.Location = new System.Drawing.Point(1008, 695);
            this.Button_Cheat.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Cheat.Name = "Button_Cheat";
            this.Button_Cheat.Size = new System.Drawing.Size(107, 46);
            this.Button_Cheat.TabIndex = 103;
            this.Button_Cheat.Text = "Cheat";
            this.Button_Cheat.UseVisualStyleBackColor = true;
            this.Button_Cheat.Click += new System.EventHandler(this.Button_Cheat_Click);
            // 
            // Timer
            // 
            this.Timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // Label_Paused
            // 
            this.Label_Paused.AutoSize = true;
            this.Label_Paused.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Label_Paused.Font = new System.Drawing.Font("Courier New", 249.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Paused.Location = new System.Drawing.Point(20, 166);
            this.Label_Paused.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Paused.Name = "Label_Paused";
            this.Label_Paused.Size = new System.Drawing.Size(0, 472);
            this.Label_Paused.TabIndex = 104;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1131, 756);
            this.Controls.Add(this.Label_Paused);
            this.Controls.Add(this.Button_Cheat);
            this.Controls.Add(this.Label_Difficulty);
            this.Controls.Add(this.Label_Average);
            this.Controls.Add(this.Label_Fastest);
            this.Controls.Add(this.Label_Title);
            this.Controls.Add(this.Label_Puzzle_Sum_D1);
            this.Controls.Add(this.Label_Puzzle_Sum_R7);
            this.Controls.Add(this.Label_Puzzle_Sum_R6);
            this.Controls.Add(this.Label_Puzzle_Sum_R5);
            this.Controls.Add(this.Label_Puzzle_Sum_R4);
            this.Controls.Add(this.Label_Puzzle_Sum_R3);
            this.Controls.Add(this.Label_Puzzle_Sum_R2);
            this.Controls.Add(this.Label_Puzzle_Sum_R1);
            this.Controls.Add(this.Label_Puzzle_Sum_C7);
            this.Controls.Add(this.Label_Puzzle_Sum_C6);
            this.Controls.Add(this.Label_Puzzle_Sum_C5);
            this.Controls.Add(this.Label_Puzzle_Sum_C4);
            this.Controls.Add(this.Label_Puzzle_Sum_C3);
            this.Controls.Add(this.Label_Puzzle_Sum_C2);
            this.Controls.Add(this.Label_Puzzle_Sum_C1);
            this.Controls.Add(this.Label_Puzzle_Sum_D2);
            this.Controls.Add(this.Button_Pause);
            this.Controls.Add(this.Label_Timer);
            this.Controls.Add(this.Label_Puzzle_D1);
            this.Controls.Add(this.Label_Puzzle_C7);
            this.Controls.Add(this.Label_Puzzle_C6);
            this.Controls.Add(this.Label_Puzzle_C5);
            this.Controls.Add(this.Label_Puzzle_C4);
            this.Controls.Add(this.Label_Puzzle_C3);
            this.Controls.Add(this.Label_Puzzle_C2);
            this.Controls.Add(this.Label_Puzzle_C1);
            this.Controls.Add(this.Label_Puzzle_D2);
            this.Controls.Add(this.Label_Puzzle_R7);
            this.Controls.Add(this.Label_Puzzle_R6);
            this.Controls.Add(this.Label_Puzzle_R5);
            this.Controls.Add(this.Label_Puzzle_R4);
            this.Controls.Add(this.Label_Puzzle_R3);
            this.Controls.Add(this.Label_Puzzle_R2);
            this.Controls.Add(this.Label_Puzzle_R1);
            this.Controls.Add(this.ComboBox_Difficulty);
            this.Controls.Add(this.Button_Create_Puzzle);
            this.Controls.Add(this.Textbox_Puzzle_49);
            this.Controls.Add(this.Textbox_Puzzle_48);
            this.Controls.Add(this.Textbox_Puzzle_47);
            this.Controls.Add(this.Textbox_Puzzle_46);
            this.Controls.Add(this.Textbox_Puzzle_45);
            this.Controls.Add(this.Textbox_Puzzle_44);
            this.Controls.Add(this.Textbox_Puzzle_42);
            this.Controls.Add(this.Textbox_Puzzle_41);
            this.Controls.Add(this.Textbox_Puzzle_40);
            this.Controls.Add(this.Textbox_Puzzle_39);
            this.Controls.Add(this.Textbox_Puzzle_38);
            this.Controls.Add(this.Textbox_Puzzle_37);
            this.Controls.Add(this.Textbox_Puzzle_35);
            this.Controls.Add(this.Textbox_Puzzle_34);
            this.Controls.Add(this.Textbox_Puzzle_33);
            this.Controls.Add(this.Textbox_Puzzle_32);
            this.Controls.Add(this.Textbox_Puzzle_31);
            this.Controls.Add(this.Textbox_Puzzle_30);
            this.Controls.Add(this.Textbox_Puzzle_28);
            this.Controls.Add(this.Textbox_Puzzle_27);
            this.Controls.Add(this.Textbox_Puzzle_26);
            this.Controls.Add(this.Textbox_Puzzle_25);
            this.Controls.Add(this.Textbox_Puzzle_24);
            this.Controls.Add(this.Textbox_Puzzle_23);
            this.Controls.Add(this.Textbox_Puzzle_21);
            this.Controls.Add(this.Textbox_Puzzle_20);
            this.Controls.Add(this.Textbox_Puzzle_19);
            this.Controls.Add(this.Textbox_Puzzle_18);
            this.Controls.Add(this.Textbox_Puzzle_17);
            this.Controls.Add(this.Textbox_Puzzle_16);
            this.Controls.Add(this.Textbox_Puzzle_15);
            this.Controls.Add(this.Textbox_Puzzle_14);
            this.Controls.Add(this.Textbox_Puzzle_13);
            this.Controls.Add(this.Textbox_Puzzle_12);
            this.Controls.Add(this.Textbox_Puzzle_11);
            this.Controls.Add(this.Textbox_Puzzle_10);
            this.Controls.Add(this.Textbox_Puzzle_9);
            this.Controls.Add(this.Textbox_Puzzle_8);
            this.Controls.Add(this.Textbox_Puzzle_43);
            this.Controls.Add(this.Textbox_Puzzle_36);
            this.Controls.Add(this.Textbox_Puzzle_29);
            this.Controls.Add(this.Textbox_Puzzle_22);
            this.Controls.Add(this.Textbox_Puzzle_7);
            this.Controls.Add(this.Textbox_Puzzle_6);
            this.Controls.Add(this.Textbox_Puzzle_5);
            this.Controls.Add(this.Textbox_Puzzle_4);
            this.Controls.Add(this.Textbox_Puzzle_3);
            this.Controls.Add(this.Textbox_Puzzle_2);
            this.Controls.Add(this.Textbox_Puzzle_1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Assignment 5: Not Sudoku";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Textbox_Puzzle_1;
        private System.Windows.Forms.TextBox Textbox_Puzzle_2;
        private System.Windows.Forms.TextBox Textbox_Puzzle_3;
        private System.Windows.Forms.TextBox Textbox_Puzzle_4;
        private System.Windows.Forms.TextBox Textbox_Puzzle_5;
        private System.Windows.Forms.TextBox Textbox_Puzzle_6;
        private System.Windows.Forms.TextBox Textbox_Puzzle_7;
        private System.Windows.Forms.TextBox Textbox_Puzzle_36;
        private System.Windows.Forms.TextBox Textbox_Puzzle_29;
        private System.Windows.Forms.TextBox Textbox_Puzzle_22;
        private System.Windows.Forms.TextBox Textbox_Puzzle_43;
        private System.Windows.Forms.TextBox Textbox_Puzzle_14;
        private System.Windows.Forms.TextBox Textbox_Puzzle_13;
        private System.Windows.Forms.TextBox Textbox_Puzzle_12;
        private System.Windows.Forms.TextBox Textbox_Puzzle_11;
        private System.Windows.Forms.TextBox Textbox_Puzzle_10;
        private System.Windows.Forms.TextBox Textbox_Puzzle_9;
        private System.Windows.Forms.TextBox Textbox_Puzzle_8;
        private System.Windows.Forms.TextBox Textbox_Puzzle_21;
        private System.Windows.Forms.TextBox Textbox_Puzzle_20;
        private System.Windows.Forms.TextBox Textbox_Puzzle_19;
        private System.Windows.Forms.TextBox Textbox_Puzzle_18;
        private System.Windows.Forms.TextBox Textbox_Puzzle_17;
        private System.Windows.Forms.TextBox Textbox_Puzzle_16;
        private System.Windows.Forms.TextBox Textbox_Puzzle_15;
        private System.Windows.Forms.TextBox Textbox_Puzzle_42;
        private System.Windows.Forms.TextBox Textbox_Puzzle_41;
        private System.Windows.Forms.TextBox Textbox_Puzzle_40;
        private System.Windows.Forms.TextBox Textbox_Puzzle_39;
        private System.Windows.Forms.TextBox Textbox_Puzzle_38;
        private System.Windows.Forms.TextBox Textbox_Puzzle_37;
        private System.Windows.Forms.TextBox Textbox_Puzzle_35;
        private System.Windows.Forms.TextBox Textbox_Puzzle_34;
        private System.Windows.Forms.TextBox Textbox_Puzzle_33;
        private System.Windows.Forms.TextBox Textbox_Puzzle_32;
        private System.Windows.Forms.TextBox Textbox_Puzzle_31;
        private System.Windows.Forms.TextBox Textbox_Puzzle_30;
        private System.Windows.Forms.TextBox Textbox_Puzzle_28;
        private System.Windows.Forms.TextBox Textbox_Puzzle_27;
        private System.Windows.Forms.TextBox Textbox_Puzzle_26;
        private System.Windows.Forms.TextBox Textbox_Puzzle_25;
        private System.Windows.Forms.TextBox Textbox_Puzzle_24;
        private System.Windows.Forms.TextBox Textbox_Puzzle_23;
        private System.Windows.Forms.TextBox Textbox_Puzzle_49;
        private System.Windows.Forms.TextBox Textbox_Puzzle_48;
        private System.Windows.Forms.TextBox Textbox_Puzzle_47;
        private System.Windows.Forms.TextBox Textbox_Puzzle_46;
        private System.Windows.Forms.TextBox Textbox_Puzzle_45;
        private System.Windows.Forms.TextBox Textbox_Puzzle_44;
        private System.Windows.Forms.Button Button_Create_Puzzle;
        private System.Windows.Forms.ComboBox ComboBox_Difficulty;
        private System.Windows.Forms.Label Label_Puzzle_R1;
        private System.Windows.Forms.Label Label_Puzzle_R2;
        private System.Windows.Forms.Label Label_Puzzle_R3;
        private System.Windows.Forms.Label Label_Puzzle_R4;
        private System.Windows.Forms.Label Label_Puzzle_R5;
        private System.Windows.Forms.Label Label_Puzzle_R6;
        private System.Windows.Forms.Label Label_Puzzle_R7;
        private System.Windows.Forms.Label Label_Puzzle_D2;
        private System.Windows.Forms.Label Label_Puzzle_C1;
        private System.Windows.Forms.Label Label_Puzzle_C2;
        private System.Windows.Forms.Label Label_Puzzle_C3;
        private System.Windows.Forms.Label Label_Puzzle_C4;
        private System.Windows.Forms.Label Label_Puzzle_C5;
        private System.Windows.Forms.Label Label_Puzzle_C6;
        private System.Windows.Forms.Label Label_Puzzle_C7;
        private System.Windows.Forms.Label Label_Puzzle_D1;
        private System.Windows.Forms.Label Label_Timer;
        private System.Windows.Forms.Button Button_Pause;
        private System.Windows.Forms.Label Label_Puzzle_Sum_C7;
        private System.Windows.Forms.Label Label_Puzzle_Sum_C6;
        private System.Windows.Forms.Label Label_Puzzle_Sum_C5;
        private System.Windows.Forms.Label Label_Puzzle_Sum_C4;
        private System.Windows.Forms.Label Label_Puzzle_Sum_C3;
        private System.Windows.Forms.Label Label_Puzzle_Sum_C2;
        private System.Windows.Forms.Label Label_Puzzle_Sum_C1;
        private System.Windows.Forms.Label Label_Puzzle_Sum_D2;
        private System.Windows.Forms.Label Label_Puzzle_Sum_D1;
        private System.Windows.Forms.Label Label_Puzzle_Sum_R7;
        private System.Windows.Forms.Label Label_Puzzle_Sum_R6;
        private System.Windows.Forms.Label Label_Puzzle_Sum_R5;
        private System.Windows.Forms.Label Label_Puzzle_Sum_R4;
        private System.Windows.Forms.Label Label_Puzzle_Sum_R3;
        private System.Windows.Forms.Label Label_Puzzle_Sum_R2;
        private System.Windows.Forms.Label Label_Puzzle_Sum_R1;
        private System.Windows.Forms.Label Label_Title;
        private System.Windows.Forms.Label Label_Fastest;
        private System.Windows.Forms.Label Label_Average;
        private System.Windows.Forms.Label Label_Difficulty;
        private System.Windows.Forms.Button Button_Cheat;
        private System.Windows.Forms.Timer Timer;
        private System.Windows.Forms.Label Label_Paused;
    }
}

